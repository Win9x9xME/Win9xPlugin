package com.win9xplugin.utils;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class DebugLogger {

    private static JavaPlugin plugin;
    private static boolean debugEnabled = false;
    private static final String PREFIX = ChatColor.GRAY + "[Debug] " + ChatColor.WHITE;

    public static void init(JavaPlugin pl) {
        plugin = pl;
        debugEnabled = pl.getConfig().getBoolean("debug.enabled", false);
    }

    public static void reload() {
        if (plugin != null) {
            debugEnabled = plugin.getConfig().getBoolean("debug.enabled", false);
        }
    }

    public static boolean isDebugEnabled() {
        return debugEnabled;
    }

    public static void setDebugEnabled(boolean enabled) {
        debugEnabled = enabled;
        if (plugin != null) {
            plugin.getConfig().set("debug.enabled", enabled);
            plugin.saveConfig();
        }
    }

    public static void info(String message) {
        if (plugin != null) {
            plugin.getLogger().info(message);
        }
        broadcastToPlayers(ChatColor.WHITE + message);
    }

    public static void warning(String message) {
        if (plugin != null) {
            plugin.getLogger().warning(message);
        }
        broadcastToPlayers(ChatColor.YELLOW + message);
    }

    public static void severe(String message) {
        if (plugin != null) {
            plugin.getLogger().severe(message);
        }
        broadcastToPlayers(ChatColor.RED + message);
    }

    public static void debug(String message) {
        if (debugEnabled) {
            if (plugin != null) {
                plugin.getLogger().info("[Debug] " + message);
            }
            broadcastToPlayers(PREFIX + message);
        }
    }

    public static void log(String message) {
        if (plugin != null) {
            plugin.getLogger().info(message);
        }
        if (debugEnabled) {
            broadcastToPlayers(ChatColor.GRAY + message);
        }
    }

    private static void broadcastToPlayers(String message) {
        if (!debugEnabled) {
            return;
        }
        if (Bukkit.getOnlinePlayers().isEmpty()) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasPermission("win9xplugin.debug") || player.isOp()) {
                player.sendMessage(PREFIX + ChatColor.stripColor(message));
            }
        }
    }

    public static void sendToPlayer(Player player, String message) {
        if (debugEnabled) {
            player.sendMessage(PREFIX + message);
        }
    }

    public static void sendToPlayerRaw(Player player, String message) {
        if (debugEnabled) {
            player.sendMessage(message);
        }
    }
}
