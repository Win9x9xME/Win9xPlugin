package com.win9xplugin.gui;

import com.win9xplugin.Win9xPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class TrashCanGUI {

    private static final int SLOTS = 54; // 6x9
    private static final String GUI_TITLE = ChatColor.DARK_GRAY + "垃圾桶";
    private static Win9xPlugin plugin;

    public static void setPlugin(Win9xPlugin win9xPlugin) {
        plugin = win9xPlugin;
    }

    public static void openTrashCan(Player player) {
        Inventory inventory = Bukkit.createInventory(new TrashCanHolder(), SLOTS, GUI_TITLE);
        player.openInventory(inventory);
    }

    private static class TrashCanHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
