package com.win9xplugin.gui;

import com.win9xplugin.weapons.Backpack;
import com.win9xplugin.weapons.BrandGlue;
import com.win9xplugin.weapons.CheapGlue;
import com.win9xplugin.weapons.ElementalArmor;
import com.win9xplugin.weapons.ElementalBow;
import com.win9xplugin.weapons.ElementalMaterials;
import com.win9xplugin.weapons.ElementalStaff;
import com.win9xplugin.weapons.ElementalSword;
import com.win9xplugin.weapons.GuideBook;
import com.win9xplugin.weapons.PhoenixArmor;
import com.win9xplugin.weapons.PhoenixBow;
import com.win9xplugin.weapons.PhoenixMaterials;
import com.win9xplugin.weapons.PhoenixStaff;
import com.win9xplugin.weapons.PhoenixSword;
import com.win9xplugin.weapons.ChainPickaxe;
import com.win9xplugin.weapons.PoorGlue;
import com.win9xplugin.weapons.RepairAgent;
import com.win9xplugin.weapons.TrashCan;
import com.win9xplugin.weapons.WPFurnace;
import com.win9xplugin.weapons.WPRepairMachine;
import com.win9xplugin.weapons.WPWorkbench;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class GuideGUI implements Listener {

    private final JavaPlugin plugin;
    private static final String MAIN_MENU_TITLE = ChatColor.GOLD + "" + ChatColor.BOLD + "Win9xPlugin 指南";
    private static final String RECIPE_TITLE = ChatColor.GOLD + "" + ChatColor.BOLD + "配方详情";
    private static final String SEARCH_TITLE = ChatColor.AQUA + "" + ChatColor.BOLD + "搜索物品";
    private static final int GUI_SIZE = 54;

    private static final String VIEW_MAIN = "MAIN";
    private static final String VIEW_CATEGORY = "CATEGORY";

    private static final String CATEGORY_WEAPON = "武器";
    private static final String CATEGORY_TOOL = "工具";
    private static final String CATEGORY_ARMOR = "装备";
    private static final String CATEGORY_MATERIAL = "材料";
    private static final String CATEGORY_MACHINE = "机器";
    private static final String CATEGORY_OTHER = "杂项";
    private static final String CATEGORY_ALL = "全部";

    private final Map<Player, Integer> playerCurrentPage = new HashMap<>();
    private final Map<Player, String> playerCurrentView = new HashMap<>();
    private final Map<Player, String> playerCurrentCategory = new HashMap<>();
    private final Map<Player, String> playerSearchInput = new HashMap<>();
    private final Map<Player, Integer> playerSearchPage = new HashMap<>();
    private final Map<Player, Integer> playerCategoryPage = new HashMap<>();
    private final Set<Player> playersInSearchMode = new HashSet<>();

    private static final List<String> ALL_CATEGORIES = List.of(
            CATEGORY_ALL, CATEGORY_WEAPON, CATEGORY_TOOL, CATEGORY_ARMOR,
            CATEGORY_MATERIAL, CATEGORY_MACHINE, CATEGORY_OTHER
    );
    private static final int CATEGORIES_PER_PAGE = 5;
    private static final int[] CATEGORY_SLOTS = {0, 1, 2, 3, 4};

    public GuideGUI(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (!GuideBook.isGuideBook(player.getInventory().getItemInMainHand())) {
            return;
        }
        event.setCancelled(true);
        openMainMenu(player);
    }

    @EventHandler
    public void onAsyncPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (playersInSearchMode.contains(player)) {
            event.setCancelled(true);
            String searchQuery = event.getMessage().trim();
            if (!searchQuery.isEmpty()) {
                playersInSearchMode.remove(player);
                Bukkit.getScheduler().runTask(plugin, () -> openSearchGUI(player, searchQuery));
            }
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        cleanupPlayerState(player);
    }

    private void cleanupPlayerState(Player player) {
        playerCurrentPage.remove(player);
        playerCurrentView.remove(player);
        playerCurrentCategory.remove(player);
        playerSearchInput.remove(player);
        playerSearchPage.remove(player);
        playerCategoryPage.remove(player);
        playersInSearchMode.remove(player);
    }

    public void openMainMenu(Player player) {
        playerCurrentPage.put(player, 0);
        playerCategoryPage.put(player, 0);
        playerCurrentView.put(player, VIEW_MAIN);
        playerCurrentCategory.put(player, CATEGORY_ALL);
        openInventoryView(player);
    }

    private void openCategoryView(Player player, String category) {
        playerCurrentPage.put(player, 0);
        playerCurrentView.put(player, VIEW_CATEGORY);
        playerCurrentCategory.put(player, category);
        openInventoryView(player);
    }

    private int getCategoryPage(Player player) {
        return playerCategoryPage.getOrDefault(player, 0);
    }

    private void setCategoryPage(Player player, int page) {
        playerCategoryPage.put(player, page);
    }

    private int getCurrentPage(Player player) {
        return playerCurrentPage.getOrDefault(player, 0);
    }

    private void setCurrentPage(Player player, int page) {
        playerCurrentPage.put(player, page);
    }

    private String getCurrentView(Player player) {
        return playerCurrentView.getOrDefault(player, VIEW_MAIN);
    }

    private String getCurrentCategory(Player player) {
        return playerCurrentCategory.getOrDefault(player, CATEGORY_ALL);
    }

    private void openInventoryView(Player player) {
        Inventory inv = Bukkit.createInventory(null, GUI_SIZE, MAIN_MENU_TITLE);

        ItemStack glass = createGlassPane();
        for (int i = 0; i < GUI_SIZE; i++) {
            inv.setItem(i, glass);
        }

        setupCategoryRow(inv, player);
        setupControlRow(inv, player);

        List<ItemStack> items = getFilteredItems(player);
        int slotsPerPage = 36;
        int startIndex = getCurrentPage(player) * slotsPerPage;

        for (int i = 0; i < slotsPerPage && (startIndex + i) < items.size(); i++) {
            int row = (i / 9) + 1;
            int col = i % 9;
            int slot = row * 9 + col;
            inv.setItem(slot, items.get(startIndex + i));
        }

        player.openInventory(inv);
    }

    private void setupCategoryRow(Inventory inv, Player player) {
        String view = getCurrentView(player);
        String category = getCurrentCategory(player);

        int catPage = getCategoryPage(player);
        int totalCatPages = (int) Math.ceil((double) ALL_CATEGORIES.size() / CATEGORIES_PER_PAGE);

        int startIndex = catPage * CATEGORIES_PER_PAGE;
        int endIndex = Math.min(startIndex + CATEGORIES_PER_PAGE, ALL_CATEGORIES.size());

        for (int i = startIndex; i < endIndex; i++) {
            int slot = CATEGORY_SLOTS[i - startIndex];
            String cat = ALL_CATEGORIES.get(i);
            boolean selected = VIEW_CATEGORY.equals(view) && cat.equals(category);
            inv.setItem(slot, createCategoryButton(cat, selected));
        }

        inv.setItem(5, createGlassPane());
        inv.setItem(6, createCategoryPrevButton(catPage > 0));
        inv.setItem(7, createCurrentCategoryDisplay(category));
        inv.setItem(8, createCategoryNextButton(catPage < totalCatPages - 1));
    }

    private void setupControlRow(Inventory inv, Player player) {
        int lastRow = GUI_SIZE - 9;
        String view = getCurrentView(player);

        inv.setItem(lastRow, createSearchButton());
        inv.setItem(lastRow + 6, createPrevPageButton());
        inv.setItem(lastRow + 7, createPageIndicator(player));
        inv.setItem(lastRow + 8, createNextPageButton());

        if (VIEW_CATEGORY.equals(view)) {
            inv.setItem(lastRow + 2, createBackButton());
        }
    }

    private List<ItemStack> getFilteredItems(Player player) {
        List<ItemStack> items = new ArrayList<>();
        String view = getCurrentView(player);
        String category = getCurrentCategory(player);

        if (VIEW_MAIN.equals(view)) {
            items.addAll(getAllItems());
        } else if (VIEW_CATEGORY.equals(view)) {
            if (CATEGORY_WEAPON.equals(category)) {
                items.add(createMenuItem(
                        PhoenixStaff.createStaff(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰法杖",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "传说中的凤凰之杖"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixBow.createBow(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰之弓",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "凤凰之焰铸就的神弓"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixSword.createSword(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰之剑",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "凤凰之焰铸就的神剑"
                        )
                ));
                items.add(createMenuItem(
                        ElementalStaff.createStaff(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素法杖",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的法杖"
                        )
                ));
                items.add(createMenuItem(
                        ElementalBow.createBow(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素之弓",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的神弓"
                        )
                ));
                items.add(createMenuItem(
                        ElementalSword.createSword(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素之剑",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的神剑"
                        )
                ));
            } else if (CATEGORY_TOOL.equals(category)) {
                items.add(createMenuItem(
                        ChainPickaxe.createPickaxe(),
                        ChatColor.AQUA + "" + ChatColor.BOLD + "连锁采集稿",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "自动连锁采集周围的同类矿物"
                        )
                ));
            } else if (CATEGORY_ARMOR.equals(category)) {
                items.add(createMenuItem(
                        PhoenixArmor.createHelmet(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰战盔",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "每秒回血 +0.5 ❤"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixArmor.createChestplate(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰铠甲",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "每秒回血 +0.5 ❤"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixArmor.createLeggings(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰护腿",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "每秒回血 +0.5 ❤"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixArmor.createBoots(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰战靴",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "每秒回血 +0.5 ❤"
                        )
                ));
                items.add(createMenuItem(
                        ElementalArmor.createHelmet(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素头盔",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的头盔"
                        )
                ));
                items.add(createMenuItem(
                        ElementalArmor.createChestplate(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素胸甲",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的胸甲"
                        )
                ));
                items.add(createMenuItem(
                        ElementalArmor.createLeggings(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素护腿",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的护腿"
                        )
                ));
                items.add(createMenuItem(
                        ElementalArmor.createBoots(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素战靴",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的靴子"
                        )
                ));
            } else if (CATEGORY_MATERIAL.equals(category)) {
                items.add(createMenuItem(
                        PhoenixMaterials.createEssence(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰精华",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含凤凰的火焰精华"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixMaterials.createFireCrystal(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "烈焰水晶",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "纯净的火焰能量结晶"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixMaterials.createPhoenixFeather(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰羽毛",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "传说中凤凰的羽毛"
                        )
                ));
                items.add(createMenuItem(
                        PhoenixMaterials.createInfernoIngot(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "熔岩锭",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "熔岩与黄金的完美融合"
                        )
                ));
                items.add(createMenuItem(
                        ElementalMaterials.createElementalEssence(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素精华",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "蕴含四种元素力量的结晶"
                        )
                ));
                items.add(createMenuItem(
                        ElementalMaterials.createWaterEssence(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "水元素精华",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "纯净的水元素能量"
                        )
                ));
                items.add(createMenuItem(
                        ElementalMaterials.createEarthEssence(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "土元素精华",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "厚重的大地能量"
                        )
                ));
                items.add(createMenuItem(
                        ElementalMaterials.createFireEssence(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "火元素精华",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "炽热的火焰能量"
                        )
                ));
                items.add(createMenuItem(
                        ElementalMaterials.createAirEssence(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "气元素精华",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "轻盈的风之能量"
                        )
                ));
                items.add(createMenuItem(
                        ElementalMaterials.createElementalCore(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素核心",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "四元素融合的核心"
                        )
                ));
                items.add(createMenuItem(
                        RepairAgent.createRepairAgent(),
                        ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "万能修补剂",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "用于修复各种工具和装备"
                        )
                ));
                items.add(createMenuItem(
                        PoorGlue.createGlue(),
                        ChatColor.GRAY + "" + ChatColor.BOLD + "劣质胶水",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "随机回复 -30~10 点耐久"
                        )
                ));
                items.add(createMenuItem(
                        CheapGlue.createGlue(),
                        ChatColor.GREEN + "" + ChatColor.BOLD + "廉价胶水",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "随机回复 -15~15 点耐久"
                        )
                ));
                items.add(createMenuItem(
                        BrandGlue.createGlue(),
                        ChatColor.BLUE + "" + ChatColor.BOLD + "品牌胶水",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "稳定回复 15 点耐久"
                        )
                ));
            } else if (CATEGORY_MACHINE.equals(category)) {
                items.add(createMenuItem(
                        WPWorkbench.createWorkbench(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "WP铸造台",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "专属WP装备铸造台"
                        )
                ));
                items.add(createMenuItem(
                        WPFurnace.createFurnace(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "WP熔铸炉",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "专属WP材料熔铸炉"
                        )
                ));
                items.add(createMenuItem(
                        WPRepairMachine.createRepairMachine(),
                        ChatColor.GOLD + "" + ChatColor.BOLD + "WP修复机",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "专属WP装备修复机"
                        )
                ));
            } else if (CATEGORY_OTHER.equals(category)) {
                items.add(createMenuItem(
                        GuideBook.createGuideBook(),
                        ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "Win9xPlugin 指南",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "Win9xPlugin 使用指南"
                        )
                ));
                items.add(createMenuItem(
                        Backpack.createSmallBackpack(),
                        ChatColor.GRAY + "" + ChatColor.BOLD + "初级背包",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "容量: 2x9",
                                ChatColor.GRAY + "初次右键输入名称"
                        )
                ));
                items.add(createMenuItem(
                        Backpack.createMediumBackpack(),
                        ChatColor.BLUE + "" + ChatColor.BOLD + "中级背包",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "容量: 4x9",
                                ChatColor.GRAY + "初次右键输入名称"
                        )
                ));
                items.add(createMenuItem(
                        Backpack.createLargeBackpack(),
                        ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "高级背包",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "容量: 6x9",
                                ChatColor.GRAY + "初次右键输入名称"
                        )
                ));
                items.add(createMenuItem(
                        TrashCan.createTrashCan(),
                        ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "便携式垃圾桶",
                        List.of(
                                ChatColor.YELLOW + "点击查看合成配方",
                                "",
                                ChatColor.GRAY + "容量: 6x9",
                                ChatColor.GRAY + "关闭后物品将被清除"
                        )
                ));
            }
        }

        return items;
    }

    private String getItemCategory(ItemStack item) {
        if (!item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
            return CATEGORY_OTHER;
        }
        String name = ChatColor.stripColor(item.getItemMeta().getDisplayName());

        if (name.equals("凤凰法杖") || name.equals("凤凰之弓") || name.equals("凤凰之剑") ||
                name.equals("元素法杖") || name.equals("元素之弓") || name.equals("元素之剑")) {
            return CATEGORY_WEAPON;
        }
        if (name.equals("连锁采集稿")) {
            return CATEGORY_TOOL;
        }
        if (name.equals("凤凰战盔") || name.equals("凤凰铠甲") || name.equals("凤凰护腿") || name.equals("凤凰战靴") ||
                name.equals("元素头盔") || name.equals("元素胸甲") || name.equals("元素护腿") || name.equals("元素战靴")) {
            return CATEGORY_ARMOR;
        }
        if (name.equals("凤凰精华") || name.equals("烈焰水晶") || name.equals("凤凰羽毛") || name.equals("熔岩锭") ||
                name.equals("元素精华") || name.equals("水元素精华") || name.equals("土元素精华") ||
                name.equals("火元素精华") || name.equals("气元素精华") || name.equals("元素核心") ||
                name.equals("万能修补剂") || name.equals("劣质胶水") || name.equals("廉价胶水") || name.equals("品牌胶水")) {
            return CATEGORY_MATERIAL;
        }
        if (name.equals("WP铸造台") || name.equals("WP熔铸炉") || name.equals("WP修复机")) {
            return CATEGORY_MACHINE;
        }
        return CATEGORY_OTHER;
    }

    private List<ItemStack> getAllItems() {
        List<ItemStack> items = new ArrayList<>();

        items.add(createMenuItem(
                PhoenixStaff.createStaff(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰法杖",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "传说中的凤凰之杖"
                )
        ));

        items.add(createMenuItem(
                PhoenixBow.createBow(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰之弓",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "凤凰之焰铸就的神弓"
                )
        ));

        items.add(createMenuItem(
                PhoenixSword.createSword(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰之剑",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "凤凰之焰铸就的神剑"
                )
        ));

        items.add(createMenuItem(
                PhoenixArmor.createHelmet(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰战盔",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "每秒回血 +0.5 ❤"
                )
        ));

        items.add(createMenuItem(
                PhoenixArmor.createChestplate(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰铠甲",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "每秒回血 +0.5 ❤"
                )
        ));

        items.add(createMenuItem(
                PhoenixArmor.createLeggings(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰护腿",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "每秒回血 +0.5 ❤"
                )
        ));

        items.add(createMenuItem(
                PhoenixArmor.createBoots(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰战靴",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "每秒回血 +0.5 ❤"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createEssence(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含凤凰的火焰精华"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createFireCrystal(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "烈焰水晶",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "纯净的火焰能量结晶"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createPhoenixFeather(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰羽毛",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "传说中凤凰的羽毛"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createInfernoIngot(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "熔岩锭",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "熔岩与黄金的完美融合"
                )
        ));

        items.add(createMenuItem(
                WPWorkbench.createWorkbench(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "WP铸造台",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "专属WP装备铸造台"
                )
        ));

        items.add(createMenuItem(
                WPFurnace.createFurnace(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "WP熔铸炉",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "专属WP材料熔铸炉"
                )
        ));

        items.add(createMenuItem(
                WPRepairMachine.createRepairMachine(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "WP修复机",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "专属WP装备修复机"
                )
        ));

        items.add(createMenuItem(
                RepairAgent.createRepairAgent(),
                ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "万能修补剂",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "用于修复各种工具和装备"
                )
        ));

        items.add(createMenuItem(
                ElementalStaff.createStaff(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素法杖",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的法杖"
                )
        ));

        items.add(createMenuItem(
                ElementalBow.createBow(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素之弓",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的神弓"
                )
        ));

        items.add(createMenuItem(
                ElementalSword.createSword(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素之剑",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的神剑"
                )
        ));

        items.add(createMenuItem(
                ElementalArmor.createHelmet(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素头盔",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的头盔"
                )
        ));

        items.add(createMenuItem(
                ElementalArmor.createChestplate(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素胸甲",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的胸甲"
                )
        ));

        items.add(createMenuItem(
                ElementalArmor.createLeggings(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素护腿",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的护腿"
                )
        ));

        items.add(createMenuItem(
                ElementalArmor.createBoots(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素战靴",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的靴子"
                )
        ));

        items.add(createMenuItem(
                ChainPickaxe.createPickaxe(),
                ChatColor.AQUA + "" + ChatColor.BOLD + "连锁采集稿",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "自动连锁采集周围的同类矿物"
                )
        ));

        items.add(createMenuItem(
                ElementalMaterials.createElementalEssence(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含四种元素力量的结晶"
                )
        ));

        items.add(createMenuItem(
                ElementalMaterials.createWaterEssence(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "水元素精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "纯净的水元素能量"
                )
        ));

        items.add(createMenuItem(
                ElementalMaterials.createEarthEssence(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "土元素精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "厚重的大地能量"
                )
        ));

        items.add(createMenuItem(
                ElementalMaterials.createFireEssence(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "火元素精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "炽热的火焰能量"
                )
        ));

        items.add(createMenuItem(
                ElementalMaterials.createAirEssence(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "气元素精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "轻盈的风之能量"
                )
        ));

        items.add(createMenuItem(
                ElementalMaterials.createElementalCore(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素核心",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "四元素融合的核心"
                )
        ));

        items.add(createMenuItem(
                GuideBook.createGuideBook(),
                ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "Win9xPlugin 指南",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "Win9xPlugin 使用指南"
                )
        ));

        items.add(createMenuItem(
                Backpack.createSmallBackpack(),
                ChatColor.GRAY + "" + ChatColor.BOLD + "初级背包",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "容量: 2x9",
                        ChatColor.GRAY + "初次右键输入名称"
                )
        ));

        items.add(createMenuItem(
                Backpack.createMediumBackpack(),
                ChatColor.BLUE + "" + ChatColor.BOLD + "中级背包",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "容量: 4x9",
                        ChatColor.GRAY + "初次右键输入名称"
                )
        ));

        items.add(createMenuItem(
                Backpack.createLargeBackpack(),
                ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "高级背包",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "容量: 6x9",
                        ChatColor.GRAY + "初次右键输入名称"
                )
        ));

        items.add(createMenuItem(
                TrashCan.createTrashCan(),
                ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "便携式垃圾桶",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "容量: 6x9",
                        ChatColor.GRAY + "关闭后物品将被清除"
                )
        ));

        items.add(createMenuItem(
                WPWorkbench.createWorkbench(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "WP铸造台",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "专属WP装备铸造台"
                )
        ));

        items.add(createMenuItem(
                WPFurnace.createFurnace(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "WP熔铸炉",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "专属WP材料熔铸炉"
                )
        ));

        items.add(createMenuItem(
                WPRepairMachine.createRepairMachine(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "WP修复机",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "专属WP装备修复机"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createEssence(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰精华",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "蕴含凤凰的火焰精华"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createFireCrystal(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "烈焰水晶",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "纯净的火焰能量结晶"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createPhoenixFeather(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰羽毛",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "传说中凤凰的羽毛"
                )
        ));

        items.add(createMenuItem(
                PhoenixMaterials.createInfernoIngot(),
                ChatColor.GOLD + "" + ChatColor.BOLD + "熔岩锭",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "熔岩与黄金的完美融合"
                )
        ));

        items.add(createMenuItem(
                RepairAgent.createRepairAgent(),
                ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "万能修补剂",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "用于修复各种工具和装备"
                )
        ));

        items.add(createMenuItem(
                PoorGlue.createGlue(),
                ChatColor.GRAY + "" + ChatColor.BOLD + "劣质胶水",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "随机回复 -30~10 点耐久"
                )
        ));

        items.add(createMenuItem(
                CheapGlue.createGlue(),
                ChatColor.GREEN + "" + ChatColor.BOLD + "廉价胶水",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "随机回复 -15~15 点耐久"
                )
        ));

        items.add(createMenuItem(
                BrandGlue.createGlue(),
                ChatColor.BLUE + "" + ChatColor.BOLD + "品牌胶水",
                List.of(
                        ChatColor.YELLOW + "点击查看合成配方",
                        "",
                        ChatColor.GRAY + "稳定回复 15 点耐久"
                )
        ));

        return items;
    }

    public void openSearchGUI(Player player, String searchQuery) {
        playerSearchInput.put(player, searchQuery);
        playerSearchPage.put(player, 0);
        displaySearchResults(player, searchQuery, 0);
    }

    private void displaySearchResults(Player player, String searchQuery, int page) {
        playerSearchPage.put(player, page);
        Inventory inv = Bukkit.createInventory(null, GUI_SIZE, SEARCH_TITLE);

        ItemStack glass = createGlassPane();
        for (int i = 0; i < GUI_SIZE; i++) {
            inv.setItem(i, glass);
        }

        inv.setItem(0, createSearchInputDisplay(searchQuery));
        int lastRow = GUI_SIZE - 9;
        inv.setItem(lastRow, createBackButton());
        inv.setItem(lastRow + 6, createPrevPageButton());
        inv.setItem(lastRow + 7, createPageIndicator(page + 1, getTotalPages(searchQuery)));
        inv.setItem(lastRow + 8, createNextPageButton());

        List<ItemStack> allItems = getAllItems();
        List<ItemStack> filteredItems = new ArrayList<>();

        for (ItemStack item : allItems) {
            if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                String itemName = ChatColor.stripColor(item.getItemMeta().getDisplayName());
                if (itemName.contains(searchQuery)) {
                    filteredItems.add(item);
                }
            }
        }

        int slotsPerPage = 36;
        int startIndex = page * slotsPerPage;

        if (filteredItems.isEmpty()) {
            inv.setItem(27, createNoResultItem());
        } else {
            for (int i = 0; i < slotsPerPage && (startIndex + i) < filteredItems.size(); i++) {
                int row = (i / 9) + 1;
                int col = i % 9;
                int slot = row * 9 + col;
                ItemStack item = filteredItems.get(startIndex + i);
                String category = getItemCategory(item);
                ItemStack displayItem = addCategoryToItem(item, category);
                inv.setItem(slot, displayItem);
            }
        }

        player.openInventory(inv);
    }

    private int getTotalPages(String searchQuery) {
        List<ItemStack> allItems = getAllItems();
        List<ItemStack> filteredItems = new ArrayList<>();
        for (ItemStack item : allItems) {
            if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                String itemName = ChatColor.stripColor(item.getItemMeta().getDisplayName());
                if (itemName.contains(searchQuery)) {
                    filteredItems.add(item);
                }
            }
        }
        return Math.max(1, (int) Math.ceil((double) filteredItems.size() / 36));
    }

    private ItemStack addCategoryToItem(ItemStack item, String category) {
        ItemStack result = item.clone();
        ItemMeta meta = result.getItemMeta();
        if (meta == null) {
            return result;
        }
        List<String> lore = meta.getLore();
        if (lore == null) {
            lore = new ArrayList<>();
        }
        lore.add("");
        lore.add(ChatColor.GRAY + "分类: " + ChatColor.YELLOW + category);
        meta.setLore(lore);
        result.setItemMeta(meta);
        return result;
    }

    private ItemStack createSearchInputDisplay(String searchQuery) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.WHITE + "搜索词: " + ChatColor.YELLOW + searchQuery);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "当前搜索关键词");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createBackButton() {
        ItemStack back = new ItemStack(Material.BARRIER);
        ItemMeta meta = back.getItemMeta();
        meta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "返回主菜单");
        back.setItemMeta(meta);
        return back;
    }

    private ItemStack createCategoryTitle(String category) {
        Material mat = category.equals(CATEGORY_WEAPON) ? Material.DIAMOND_SWORD :
                       category.equals(CATEGORY_TOOL) ? Material.DIAMOND_PICKAXE :
                       category.equals(CATEGORY_ARMOR) ? Material.DIAMOND_CHESTPLATE :
                       category.equals(CATEGORY_MATERIAL) ? Material.BLAZE_POWDER :
                       category.equals(CATEGORY_MACHINE) ? Material.ANVIL :
                       category.equals(CATEGORY_OTHER) ? Material.BOOK : Material.PAPER;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "【" + category + "】");
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createNoResultItem() {
        ItemStack item = new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "没有找到匹配的物品");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "请尝试其他关键词");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createSearchButton() {
        ItemStack search = new ItemStack(Material.COMPASS);
        ItemMeta meta = search.getItemMeta();
        meta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "搜索");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "点击搜索物品");
        meta.setLore(lore);
        search.setItemMeta(meta);
        return search;
    }

    private ItemStack createCategoryButton(String category, boolean selected) {
        Material mat = category.equals(CATEGORY_WEAPON) ? Material.DIAMOND_SWORD :
                       category.equals(CATEGORY_TOOL) ? Material.DIAMOND_PICKAXE :
                       category.equals(CATEGORY_ARMOR) ? Material.DIAMOND_CHESTPLATE :
                       category.equals(CATEGORY_MATERIAL) ? Material.BLAZE_POWDER :
                       category.equals(CATEGORY_MACHINE) ? Material.ANVIL :
                       category.equals(CATEGORY_OTHER) ? Material.BOOK : Material.PAPER;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(selected ? ChatColor.GREEN + "" + ChatColor.BOLD + category :
                                   ChatColor.YELLOW + category);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createCategoryPrevButton(boolean enabled) {
        ItemStack prev = new ItemStack(Material.ARROW);
        ItemMeta meta = prev.getItemMeta();
        if (enabled) {
            meta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "←");
        } else {
            meta.setDisplayName(ChatColor.GRAY + "" + ChatColor.BOLD + "←");
        }
        prev.setItemMeta(meta);
        return prev;
    }

    private ItemStack createCategoryNextButton(boolean enabled) {
        ItemStack next = new ItemStack(Material.ARROW);
        ItemMeta meta = next.getItemMeta();
        if (enabled) {
            meta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "→");
        } else {
            meta.setDisplayName(ChatColor.GRAY + "" + ChatColor.BOLD + "→");
        }
        next.setItemMeta(meta);
        return next;
    }

    private ItemStack createCurrentCategoryDisplay(String category) {
        Material mat = category.equals(CATEGORY_WEAPON) ? Material.DIAMOND_SWORD :
                       category.equals(CATEGORY_TOOL) ? Material.DIAMOND_PICKAXE :
                       category.equals(CATEGORY_ARMOR) ? Material.DIAMOND_CHESTPLATE :
                       category.equals(CATEGORY_MATERIAL) ? Material.BLAZE_POWDER :
                       category.equals(CATEGORY_MACHINE) ? Material.ANVIL :
                       category.equals(CATEGORY_OTHER) ? Material.BOOK : Material.PAPER;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "当前: " + category);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "点击查看该分类");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createPrevPageButton() {
        ItemStack prev = new ItemStack(Material.ARROW);
        ItemMeta meta = prev.getItemMeta();
        meta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "上一页");
        prev.setItemMeta(meta);
        return prev;
    }

    private ItemStack createPageIndicator(Player player) {
        List<ItemStack> items = getFilteredItems(player);
        int totalPages = Math.max(1, (int) Math.ceil((double) items.size() / 36));
        return createPageIndicator(getCurrentPage(player) + 1, totalPages);
    }

    private ItemStack createPageIndicator(int page, int totalPages) {
        ItemStack indicator = new ItemStack(Material.BOOK);
        ItemMeta meta = indicator.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "第 " + page + "/" + totalPages + " 页");
        indicator.setItemMeta(meta);
        return indicator;
    }

    private ItemStack createNextPageButton() {
        ItemStack next = new ItemStack(Material.ARROW);
        ItemMeta meta = next.getItemMeta();
        meta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "下一页");
        next.setItemMeta(meta);
        return next;
    }

    public void openRecipeGUI(Player player, ItemStack resultItem, String[] pattern, char[] keys, ItemStack[] materials, String craftType) {
        Inventory inv = Bukkit.createInventory(null, 45, RECIPE_TITLE);

        ItemStack glass = createGlassPane();
        for (int i = 0; i < 45; i++) {
            inv.setItem(i, glass);
        }

        int startSlot = 10;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int slot = startSlot + row * 9 + col;
                char c = pattern[row].charAt(col);

                if (c == ' ') {
                    inv.setItem(slot, new ItemStack(Material.AIR));
                } else {
                    for (int k = 0; k < keys.length; k++) {
                        if (keys[k] == c && materials[k] != null) {
                            inv.setItem(slot, materials[k]);
                            break;
                        }
                    }
                }
            }
        }

        ItemStack arrow = new ItemStack(Material.ARROW);
        ItemMeta arrowMeta = arrow.getItemMeta();
        arrowMeta.setDisplayName(ChatColor.GREEN + "合成结果");
        arrow.setItemMeta(arrowMeta);
        inv.setItem(23, arrow);

        inv.setItem(24, resultItem);

        ItemStack craftTypeItem = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta craftMeta = craftTypeItem.getItemMeta();
        craftMeta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "合成方式: " + craftType);
        List<String> craftLore = new ArrayList<>();
        if (craftType.equals("工作台")) {
            craftLore.add(ChatColor.GRAY + "在普通工作台中合成");
        } else if (craftType.equals("铸造台")) {
            craftLore.add(ChatColor.GRAY + "在WP铸造台中合成");
        } else if (craftType.equals("熔铸炉")) {
            craftLore.add(ChatColor.GRAY + "在WP熔铸炉中烧制");
            craftTypeItem.setType(Material.FURNACE);
        }
        craftMeta.setLore(craftLore);
        craftTypeItem.setItemMeta(craftMeta);
        inv.setItem(25, craftTypeItem);

        ItemStack back = new ItemStack(Material.RED_WOOL);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "返回主菜单");
        back.setItemMeta(backMeta);
        inv.setItem(36, back);

        ItemStack give = new ItemStack(Material.LIME_WOOL);
        ItemMeta giveMeta = give.getItemMeta();
        giveMeta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "获取此物品");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "点击获取该物品（需要管理员权限）");
        giveMeta.setLore(lore);
        give.setItemMeta(giveMeta);
        inv.setItem(44, give);

        player.openInventory(inv);
    }

    public void openFurnaceRecipeGUI(Player player, ItemStack inputItem, ItemStack resultItem, String craftType) {
        Inventory inv = Bukkit.createInventory(null, 45, RECIPE_TITLE);

        ItemStack glass = createGlassPane();
        for (int i = 0; i < 45; i++) {
            inv.setItem(i, glass);
        }

        inv.setItem(13, inputItem);

        ItemStack arrow = new ItemStack(Material.ARROW);
        ItemMeta arrowMeta = arrow.getItemMeta();
        arrowMeta.setDisplayName(ChatColor.GREEN + "烧制结果");
        arrow.setItemMeta(arrowMeta);
        inv.setItem(23, arrow);

        inv.setItem(24, resultItem);

        ItemStack furnaceItem = new ItemStack(Material.FURNACE);
        ItemMeta furnaceMeta = furnaceItem.getItemMeta();
        furnaceMeta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "烧制方式: " + craftType);
        List<String> furnaceLore = new ArrayList<>();
        furnaceLore.add(ChatColor.GRAY + "在WP熔铸炉中烧制获得");
        furnaceLore.add("");
        furnaceLore.add(ChatColor.YELLOW + "将原料放入熔铸炉");
        furnaceLore.add(ChatColor.YELLOW + "等待烧制完成即可获得");
        furnaceMeta.setLore(furnaceLore);
        furnaceItem.setItemMeta(furnaceMeta);
        inv.setItem(25, furnaceItem);

        ItemStack back = new ItemStack(Material.RED_WOOL);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + "返回主菜单");
        back.setItemMeta(backMeta);
        inv.setItem(36, back);

        ItemStack give = new ItemStack(Material.LIME_WOOL);
        ItemMeta giveMeta = give.getItemMeta();
        giveMeta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "获取此物品");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "点击获取该物品（需要管理员权限）");
        giveMeta.setLore(lore);
        give.setItemMeta(giveMeta);
        inv.setItem(44, give);

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        String title = event.getView().getTitle();
        if (!title.equals(MAIN_MENU_TITLE) && !title.equals(RECIPE_TITLE) && !title.equals(SEARCH_TITLE)) {
            return;
        }

        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) {
            return;
        }

        String name = clicked.getItemMeta().getDisplayName();

        if (title.equals(MAIN_MENU_TITLE)) {
            handleMainMenuClick(player, name);
        } else if (title.equals(RECIPE_TITLE)) {
            handleRecipeClick(player, name);
        } else if (title.equals(SEARCH_TITLE)) {
            handleSearchClick(player, name);
        }
    }

    private void handleMainMenuClick(Player player, String name) {
        String strippedName = ChatColor.stripColor(name);

        if (strippedName.equals("←")) {
            int catPage = getCategoryPage(player);
            if (catPage > 0) {
                setCategoryPage(player, catPage - 1);
                openInventoryView(player);
            }
            return;
        } else if (strippedName.equals("→")) {
            int catPage = getCategoryPage(player);
            int totalCatPages = (int) Math.ceil((double) ALL_CATEGORIES.size() / CATEGORIES_PER_PAGE);
            if (catPage < totalCatPages - 1) {
                setCategoryPage(player, catPage + 1);
                openInventoryView(player);
            }
            return;
        } else if (strippedName.startsWith("当前: ")) {
            String category = strippedName.substring(4);
            if (CATEGORY_ALL.equals(category)) {
                playerCurrentView.put(player, VIEW_MAIN);
                playerCurrentCategory.put(player, CATEGORY_ALL);
                playerCurrentPage.put(player, 0);
                openInventoryView(player);
            } else {
                openCategoryView(player, category);
            }
            return;
        } else if (strippedName.equals(CATEGORY_ALL)) {
            playerCurrentView.put(player, VIEW_MAIN);
            playerCurrentCategory.put(player, CATEGORY_ALL);
            playerCurrentPage.put(player, 0);
            openInventoryView(player);
            return;
        } else if (strippedName.equals(CATEGORY_WEAPON)) {
            openCategoryView(player, CATEGORY_WEAPON);
            return;
        } else if (strippedName.equals(CATEGORY_TOOL)) {
            openCategoryView(player, CATEGORY_TOOL);
            return;
        } else if (strippedName.equals(CATEGORY_ARMOR)) {
            openCategoryView(player, CATEGORY_ARMOR);
            return;
        } else if (strippedName.equals(CATEGORY_MATERIAL)) {
            openCategoryView(player, CATEGORY_MATERIAL);
            return;
        } else if (strippedName.equals(CATEGORY_MACHINE)) {
            openCategoryView(player, CATEGORY_MACHINE);
            return;
        } else if (strippedName.equals(CATEGORY_OTHER)) {
            openCategoryView(player, CATEGORY_OTHER);
            return;
        } else if (name.contains("返回主菜单")) {
            openMainMenu(player);
            return;
        } else if (name.contains("搜索")) {
            player.sendMessage(ChatColor.AQUA + "请在聊天框输入搜索关键词...");
            playersInSearchMode.add(player);
            player.closeInventory();
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (playersInSearchMode.contains(player)) {
                    playersInSearchMode.remove(player);
                    player.sendMessage(ChatColor.GRAY + "搜索已超时，请重新打开指南书");
                }
            }, 600);
            return;
        } else if (name.contains("上一页")) {
            int currentPage = getCurrentPage(player);
            if (currentPage > 0) {
                setCurrentPage(player, currentPage - 1);
                openInventoryView(player);
            } else {
                player.sendMessage(ChatColor.RED + "已经是第一页了！");
            }
            return;
        } else if (name.contains("下一页")) {
            List<ItemStack> items = getFilteredItems(player);
            int totalPages = Math.max(1, (int) Math.ceil((double) items.size() / 36));
            int currentPage = getCurrentPage(player);
            if (currentPage < totalPages - 1) {
                setCurrentPage(player, currentPage + 1);
                openInventoryView(player);
            } else {
                player.sendMessage(ChatColor.RED + "已经是最后一页了！");
            }
            return;
        }

        openRecipeForItem(player, name);
    }

    private void handleRecipeClick(Player player, String name) {
        if (name.contains("返回主菜单")) {
            openMainMenu(player);
        } else if (name.contains("获取此物品")) {
            if (player.isOp() || player.hasPermission("win9xplugin.guide.give")) {
                ItemStack result = player.getOpenInventory().getTopInventory().getItem(24);
                if (result != null) {
                    player.getInventory().addItem(result.clone());
                    player.sendMessage(ChatColor.GREEN + "已获取物品！");
                    player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                }
            } else {
                player.sendMessage(ChatColor.RED + "你没有权限获取此物品！");
            }
        }
    }

    private void handleSearchClick(Player player, String name) {
        if (name.contains("返回主菜单")) {
            playerSearchInput.remove(player);
            playerSearchPage.remove(player);
            openMainMenu(player);
            return;
        } else if (name.contains("上一页")) {
            int page = playerSearchPage.getOrDefault(player, 0);
            if (page > 0) {
                String query = playerSearchInput.getOrDefault(player, "");
                displaySearchResults(player, query, page - 1);
            } else {
                player.sendMessage(ChatColor.RED + "已经是第一页了！");
            }
            return;
        } else if (name.contains("下一页")) {
            int page = playerSearchPage.getOrDefault(player, 0);
            String query = playerSearchInput.getOrDefault(player, "");
            List<ItemStack> allItems = getAllItems();
            List<ItemStack> filteredItems = new ArrayList<>();
            for (ItemStack item : allItems) {
                if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                    String itemName = ChatColor.stripColor(item.getItemMeta().getDisplayName());
                    if (itemName.contains(query)) {
                        filteredItems.add(item);
                    }
                }
            }
            int totalPages = Math.max(1, (int) Math.ceil((double) filteredItems.size() / 36));
            if (page < totalPages - 1) {
                displaySearchResults(player, query, page + 1);
            } else {
                player.sendMessage(ChatColor.RED + "已经是最后一页了！");
            }
            return;
        }

        openRecipeForItem(player, name);
    }

    private void openRecipeForItem(Player player, String name) {
        String strippedName = ChatColor.stripColor(name);

        if (strippedName.equals("凤凰法杖")) {
            openStaffRecipe(player);
        } else if (strippedName.equals("凤凰之弓")) {
            openPhoenixBowRecipe(player);
        } else if (strippedName.equals("凤凰之剑")) {
            openPhoenixSwordRecipe(player);
        } else if (strippedName.equals("连锁采集稿")) {
            openChainPickaxeRecipe(player);
        } else if (strippedName.equals("凤凰战盔")) {
            openHelmetRecipe(player);
        } else if (strippedName.equals("凤凰铠甲")) {
            openChestplateRecipe(player);
        } else if (strippedName.equals("凤凰护腿")) {
            openLeggingsRecipe(player);
        } else if (strippedName.equals("凤凰战靴")) {
            openBootsRecipe(player);
        } else if (strippedName.equals("凤凰精华")) {
            openEssenceRecipe(player);
        } else if (strippedName.equals("烈焰水晶")) {
            openFireCrystalRecipe(player);
        } else if (strippedName.equals("凤凰羽毛")) {
            openPhoenixFeatherRecipe(player);
        } else if (strippedName.equals("熔岩锭")) {
            openInfernoIngotRecipe(player);
        } else if (strippedName.equals("WP铸造台")) {
            openWorkbenchRecipe(player);
        } else if (strippedName.equals("WP熔铸炉")) {
            openFurnaceRecipe(player);
        } else if (strippedName.equals("元素精华")) {
            openElementalEssenceRecipe(player);
        } else if (strippedName.equals("水元素精华")) {
            openWaterEssenceRecipe(player);
        } else if (strippedName.equals("土元素精华")) {
            openEarthEssenceRecipe(player);
        } else if (strippedName.equals("火元素精华")) {
            openFireEssenceRecipe(player);
        } else if (strippedName.equals("气元素精华")) {
            openAirEssenceRecipe(player);
        } else if (strippedName.equals("元素核心")) {
            openElementalCoreRecipe(player);
        } else if (strippedName.equals("元素法杖")) {
            openElementalStaffRecipe(player);
        } else if (strippedName.equals("元素之弓")) {
            openElementalBowRecipe(player);
        } else if (strippedName.equals("元素之剑")) {
            openElementalSwordRecipe(player);
        } else if (strippedName.equals("元素头盔")) {
            openElementalHelmetRecipe(player);
        } else if (strippedName.equals("元素胸甲")) {
            openElementalChestplateRecipe(player);
        } else if (strippedName.equals("元素护腿")) {
            openElementalLeggingsRecipe(player);
        } else if (strippedName.equals("元素战靴")) {
            openElementalBootsRecipe(player);
        } else if (strippedName.equals("Win9xPlugin 指南")) {
            openGuideRecipe(player);
        } else if (strippedName.equals("初级背包")) {
            openSmallBackpackRecipe(player);
        } else if (strippedName.equals("中级背包")) {
            openMediumBackpackRecipe(player);
        } else if (strippedName.equals("高级背包")) {
            openLargeBackpackRecipe(player);
        } else if (strippedName.equals("便携式垃圾桶")) {
            openTrashCanRecipe(player);
        } else if (strippedName.equals("WP修复机")) {
            openRepairMachineRecipe(player);
        } else if (strippedName.equals("万能修补剂")) {
            openRepairAgentRecipe(player);
        } else if (strippedName.equals("劣质胶水")) {
            openPoorGlueRecipe(player);
        } else if (strippedName.equals("廉价胶水")) {
            openCheapGlueRecipe(player);
        } else if (strippedName.equals("品牌胶水")) {
            openBrandGlueRecipe(player);
        }
    }

    private void openStaffRecipe(Player player) {
        String[] pattern = {" P ", " F ", " I "};
        char[] keys = {'P', 'F', 'I'};
        ItemStack[] materials = {
                PhoenixMaterials.createPhoenixFeather(),
                PhoenixMaterials.createFireCrystal(),
                PhoenixMaterials.createInfernoIngot()
        };
        openRecipeGUI(player, PhoenixStaff.createStaff(), pattern, keys, materials, "铸造台");
    }

    private void openPhoenixBowRecipe(Player player) {
        String[] pattern = {" PF", " F ", "I  "};
        char[] keys = {'P', 'F', 'I'};
        ItemStack[] materials = {
                PhoenixMaterials.createPhoenixFeather(),
                PhoenixMaterials.createFireCrystal(),
                PhoenixMaterials.createInfernoIngot()
        };
        openRecipeGUI(player, PhoenixBow.createBow(), pattern, keys, materials, "铸造台");
    }

    private void openPhoenixSwordRecipe(Player player) {
        String[] pattern = {" F ", " F ", " I "};
        char[] keys = {'F', 'I'};
        ItemStack[] materials = {
                PhoenixMaterials.createFireCrystal(),
                PhoenixMaterials.createInfernoIngot()
        };
        openRecipeGUI(player, PhoenixSword.createSword(), pattern, keys, materials, "铸造台");
    }

    private void openChainPickaxeRecipe(Player player) {
        String[] pattern = {"IFI", " S ", " S "};
        char[] keys = {'I', 'F', 'S'};
        ItemStack[] materials = {
                PhoenixMaterials.createInfernoIngot(),
                PhoenixMaterials.createFireCrystal(),
                createMaterialItem(Material.STICK, "木棍")
        };
        openRecipeGUI(player, ChainPickaxe.createPickaxe(), pattern, keys, materials, "铸造台");
    }

    private void openHelmetRecipe(Player player) {
        String[] pattern = {"IFI", "FCF", "   "};
        char[] keys = {'I', 'F', 'C'};
        ItemStack[] materials = {
                PhoenixMaterials.createInfernoIngot(),
                PhoenixMaterials.createFireCrystal(),
                createMaterialItem(Material.GOLDEN_HELMET, "金头盔")
        };
        openRecipeGUI(player, PhoenixArmor.createHelmet(), pattern, keys, materials, "铸造台");
    }

    private void openChestplateRecipe(Player player) {
        String[] pattern = {"FCF", "IFI", "IFI"};
        char[] keys = {'I', 'F', 'C'};
        ItemStack[] materials = {
                PhoenixMaterials.createInfernoIngot(),
                PhoenixMaterials.createFireCrystal(),
                createMaterialItem(Material.GOLDEN_CHESTPLATE, "金胸甲")
        };
        openRecipeGUI(player, PhoenixArmor.createChestplate(), pattern, keys, materials, "铸造台");
    }

    private void openLeggingsRecipe(Player player) {
        String[] pattern = {"FCF", "I I", "I I"};
        char[] keys = {'I', 'F', 'C'};
        ItemStack[] materials = {
                PhoenixMaterials.createInfernoIngot(),
                PhoenixMaterials.createFireCrystal(),
                createMaterialItem(Material.GOLDEN_LEGGINGS, "金护腿")
        };
        openRecipeGUI(player, PhoenixArmor.createLeggings(), pattern, keys, materials, "铸造台");
    }

    private void openBootsRecipe(Player player) {
        String[] pattern = {"I I", "FCF", "   "};
        char[] keys = {'I', 'F', 'C'};
        ItemStack[] materials = {
                PhoenixMaterials.createInfernoIngot(),
                PhoenixMaterials.createFireCrystal(),
                createMaterialItem(Material.GOLDEN_BOOTS, "金靴子")
        };
        openRecipeGUI(player, PhoenixArmor.createBoots(), pattern, keys, materials, "铸造台");
    }

    private void openEssenceRecipe(Player player) {
        openFurnaceRecipeGUI(player,
                createMaterialItem(Material.NETHER_STAR, "下界之星"),
                PhoenixMaterials.createEssence(),
                "熔铸炉");
    }

    private void openFireCrystalRecipe(Player player) {
        openFurnaceRecipeGUI(player,
                createMaterialItem(Material.PRISMARINE_CRYSTALS, "海晶碎片"),
                PhoenixMaterials.createFireCrystal(),
                "熔铸炉");
    }

    private void openPhoenixFeatherRecipe(Player player) {
        String[] pattern = {" E ", "EFE", " E "};
        char[] keys = {'E', 'F'};
        ItemStack[] materials = {
                PhoenixMaterials.createEssence(),
                createMaterialItem(Material.FEATHER, "羽毛")
        };
        openRecipeGUI(player, PhoenixMaterials.createPhoenixFeather(), pattern, keys, materials, "铸造台");
    }

    private void openInfernoIngotRecipe(Player player) {
        openFurnaceRecipeGUI(player,
                createMaterialItem(Material.GOLD_INGOT, "金锭"),
                PhoenixMaterials.createInfernoIngot(),
                "熔铸炉");
    }

    private void openWorkbenchRecipe(Player player) {
        String[] pattern = {"IFI", "FCF", "IFI"};
        char[] keys = {'I', 'F', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.IRON_BLOCK, "铁块"),
                createMaterialItem(Material.BLAZE_POWDER, "烈焰粉"),
                createMaterialItem(Material.CRAFTING_TABLE, "工作台")
        };
        openRecipeGUI(player, WPWorkbench.createWorkbench(), pattern, keys, materials, "工作台");
    }

    private void openFurnaceRecipe(Player player) {
        String[] pattern = {"IFI", "FCF", "IFI"};
        char[] keys = {'I', 'F', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.IRON_BLOCK, "铁块"),
                createMaterialItem(Material.BLAZE_ROD, "烈焰棒"),
                createMaterialItem(Material.FURNACE, "熔炉")
        };
        openRecipeGUI(player, WPFurnace.createFurnace(), pattern, keys, materials, "工作台");
    }

    private void openElementalEssenceRecipe(Player player) {
        String[] pattern = {"WC ", "FA ", "   "};
        char[] keys = {'W', 'C', 'F', 'A'};
        ItemStack[] materials = {
                createMaterialItem(Material.PRISMARINE_CRYSTALS, "海晶碎片"),
                createMaterialItem(Material.PRISMARINE_SHARD, "海晶砂粒"),
                createMaterialItem(Material.BLAZE_POWDER, "烈焰粉"),
                createMaterialItem(Material.GHAST_TEAR, "恶魂之泪")
        };
        openRecipeGUI(player, ElementalMaterials.createElementalEssence(), pattern, keys, materials, "铸造台");
    }

    private void openWaterEssenceRecipe(Player player) {
        String[] pattern = {"PPP", "PWP", "PPP"};
        char[] keys = {'P', 'W'};
        ItemStack[] materials = {
                createMaterialItem(Material.PRISMARINE_CRYSTALS, "海晶碎片"),
                createMaterialItem(Material.WATER_BUCKET, "水桶")
        };
        openRecipeGUI(player, ElementalMaterials.createWaterEssence(), pattern, keys, materials, "工作台");
    }

    private void openEarthEssenceRecipe(Player player) {
        String[] pattern = {"DDD", "DED", "DDD"};
        char[] keys = {'D', 'E'};
        ItemStack[] materials = {
                createMaterialItem(Material.DIRT, "泥土"),
                createMaterialItem(Material.EMERALD, "绿宝石")
        };
        openRecipeGUI(player, ElementalMaterials.createEarthEssence(), pattern, keys, materials, "工作台");
    }

    private void openFireEssenceRecipe(Player player) {
        String[] pattern = {"LLL", "LFL", "LLL"};
        char[] keys = {'L', 'F'};
        ItemStack[] materials = {
                createMaterialItem(Material.LAVA_BUCKET, "岩浆桶"),
                createMaterialItem(Material.BLAZE_ROD, "烈焰棒")
        };
        openRecipeGUI(player, ElementalMaterials.createFireEssence(), pattern, keys, materials, "工作台");
    }

    private void openAirEssenceRecipe(Player player) {
        String[] pattern = {"PPP", "PFP", "PPP"};
        char[] keys = {'P', 'F'};
        ItemStack[] materials = {
                createMaterialItem(Material.PHANTOM_MEMBRANE, "幻翼膜"),
                createMaterialItem(Material.FEATHER, "羽毛")
        };
        openRecipeGUI(player, ElementalMaterials.createAirEssence(), pattern, keys, materials, "工作台");
    }

    private void openElementalCoreRecipe(Player player) {
        String[] pattern = {"WE ", "EA ", "   "};
        char[] keys = {'W', 'E', 'A'};
        ItemStack[] materials = {
                ElementalMaterials.createWaterEssence(),
                ElementalMaterials.createEarthEssence(),
                ElementalMaterials.createAirEssence()
        };
        openRecipeGUI(player, ElementalMaterials.createElementalCore(), pattern, keys, materials, "铸造台");
    }

    private void openElementalStaffRecipe(Player player) {
        String[] pattern = {"  E", " C ", "S  "};
        char[] keys = {'E', 'C', 'S'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                ElementalMaterials.createElementalCore(),
                createMaterialItem(Material.STICK, "木棍")
        };
        openRecipeGUI(player, ElementalStaff.createStaff(), pattern, keys, materials, "铸造台");
    }

    private void openElementalBowRecipe(Player player) {
        String[] pattern = {" EC", " E ", "S  "};
        char[] keys = {'E', 'C', 'S'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                ElementalMaterials.createElementalCore(),
                createMaterialItem(Material.STICK, "木棍")
        };
        openRecipeGUI(player, ElementalBow.createBow(), pattern, keys, materials, "铸造台");
    }

    private void openElementalSwordRecipe(Player player) {
        String[] pattern = {" E ", " E ", " C "};
        char[] keys = {'E', 'C'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                ElementalMaterials.createElementalCore()
        };
        openRecipeGUI(player, ElementalSword.createSword(), pattern, keys, materials, "铸造台");
    }

    private void openElementalHelmetRecipe(Player player) {
        String[] pattern = {"EEE", "ECE", "   "};
        char[] keys = {'E', 'C'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                createMaterialItem(Material.DIAMOND_HELMET, "钻石头盔")
        };
        openRecipeGUI(player, ElementalArmor.createHelmet(), pattern, keys, materials, "铸造台");
    }

    private void openElementalChestplateRecipe(Player player) {
        String[] pattern = {"ECE", "EEE", "EEE"};
        char[] keys = {'E', 'C'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                createMaterialItem(Material.DIAMOND_CHESTPLATE, "钻石胸甲")
        };
        openRecipeGUI(player, ElementalArmor.createChestplate(), pattern, keys, materials, "铸造台");
    }

    private void openElementalLeggingsRecipe(Player player) {
        String[] pattern = {"ECE", "E E", "E E"};
        char[] keys = {'E', 'C'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                createMaterialItem(Material.DIAMOND_LEGGINGS, "钻石护腿")
        };
        openRecipeGUI(player, ElementalArmor.createLeggings(), pattern, keys, materials, "铸造台");
    }

    private void openElementalBootsRecipe(Player player) {
        String[] pattern = {"E E", "ECE", "   "};
        char[] keys = {'E', 'C'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                createMaterialItem(Material.DIAMOND_BOOTS, "钻石靴子")
        };
        openRecipeGUI(player, ElementalArmor.createBoots(), pattern, keys, materials, "铸造台");
    }

    private void openGuideRecipe(Player player) {
        String[] pattern = {" P ", "PBP", " P "};
        char[] keys = {'P', 'B'};
        ItemStack[] materials = {
                createMaterialItem(Material.PAPER, "纸"),
                createMaterialItem(Material.BOOK, "书")
        };
        openRecipeGUI(player, GuideBook.createGuideBook(), pattern, keys, materials, "工作台");
    }

    private void openSmallBackpackRecipe(Player player) {
        String[] pattern = {"LLL", "LCL", "LLL"};
        char[] keys = {'L', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.LEATHER, "皮革"),
                createMaterialItem(Material.CHEST, "箱子")
        };
        openRecipeGUI(player, Backpack.createSmallBackpack(), pattern, keys, materials, "工作台");
    }

    private void openMediumBackpackRecipe(Player player) {
        String[] pattern = {"LLL", "LCL", "LLL"};
        char[] keys = {'L', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.LEATHER, "皮革"),
                createMaterialItem(Material.TRAPPED_CHEST, "陷阱箱")
        };
        openRecipeGUI(player, Backpack.createMediumBackpack(), pattern, keys, materials, "工作台");
    }

    private void openLargeBackpackRecipe(Player player) {
        String[] pattern = {"LLL", "LCL", "LLL"};
        char[] keys = {'L', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.LEATHER, "皮革"),
                createMaterialItem(Material.SHULKER_BOX, "潜影盒")
        };
        openRecipeGUI(player, Backpack.createLargeBackpack(), pattern, keys, materials, "工作台");
    }

    private void openTrashCanRecipe(Player player) {
        String[] pattern = {"OOO", "OBO", "OOO"};
        char[] keys = {'O', 'B'};
        ItemStack[] materials = {
                createMaterialItem(Material.OBSIDIAN, "黑曜石"),
                createMaterialItem(Material.BARREL, "木桶")
        };
        openRecipeGUI(player, TrashCan.createTrashCan(), pattern, keys, materials, "工作台");
    }

    private void openRepairMachineRecipe(Player player) {
        String[] pattern = {"III", "IAI", "III"};
        char[] keys = {'I', 'A'};
        ItemStack[] materials = {
                createMaterialItem(Material.IRON_BLOCK, "铁块"),
                createMaterialItem(Material.ANVIL, "铁砧")
        };
        openRecipeGUI(player, WPRepairMachine.createRepairMachine(), pattern, keys, materials, "工作台");
    }

    private void openRepairAgentRecipe(Player player) {
        String[] pattern = {" E ", "EDE", " E "};
        char[] keys = {'E', 'D'};
        ItemStack[] materials = {
                ElementalMaterials.createElementalEssence(),
                createMaterialItem(Material.DIAMOND, "钻石")
        };
        openRecipeGUI(player, RepairAgent.createRepairAgent(), pattern, keys, materials, "工作台");
    }

    private void openPoorGlueRecipe(Player player) {
        String[] pattern = {"S", "C", "S"};
        char[] keys = {'S', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.STRING, "线"),
                createMaterialItem(Material.CLAY_BALL, "黏土球")
        };
        openRecipeGUI(player, PoorGlue.createGlue(), pattern, keys, materials, "工作台");
    }

    private void openCheapGlueRecipe(Player player) {
        String[] pattern = {"S", "C", "S"};
        char[] keys = {'S', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.STRING, "线"),
                createMaterialItem(Material.SLIME_BALL, "史莱姆球")
        };
        openRecipeGUI(player, CheapGlue.createGlue(), pattern, keys, materials, "工作台");
    }

    private void openBrandGlueRecipe(Player player) {
        String[] pattern = {"S", "C", "S"};
        char[] keys = {'S', 'C'};
        ItemStack[] materials = {
                createMaterialItem(Material.STRING, "线"),
                createMaterialItem(Material.HONEYCOMB, "蜂蜜块")
        };
        openRecipeGUI(player, BrandGlue.createGlue(), pattern, keys, materials, "工作台");
    }

    private ItemStack createMaterialItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.WHITE + name);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createMenuItem(ItemStack baseItem, String name, List<String> loreLines) {
        ItemStack item = baseItem.clone();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            List<String> lore = new ArrayList<>();
            lore.addAll(loreLines);
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createGlassPane() {
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            glass.setItemMeta(meta);
        }
        return glass;
    }
}
