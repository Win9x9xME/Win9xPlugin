package com.win9xplugin.gui;

import com.win9xplugin.weapons.BrandGlue;
import com.win9xplugin.weapons.CheapGlue;
import com.win9xplugin.weapons.PoorGlue;
import com.win9xplugin.weapons.RepairAgent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RepairGUI implements Listener {

    private static final int GUI_SIZE = 27;
    private static final String GUI_TITLE = ChatColor.GOLD + "" + ChatColor.BOLD + "WP修复机";

    // Slot indices
    private static final int SLOT_INPUT = 11;
    private static final int SLOT_AGENT = 13;
    private static final int SLOT_OUTPUT = 15;

    private static final Map<UUID, Inventory> openRepairGUIs = new HashMap<>();
    private static JavaPlugin plugin;

    public static void setPlugin(JavaPlugin pl) {
        plugin = pl;
    }

    public static void openRepairGUI(Player player) {
        Inventory inventory = Bukkit.createInventory(new RepairHolder(), GUI_SIZE, GUI_TITLE);

        // 边框
        ItemStack border = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta borderMeta = border.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            border.setItemMeta(borderMeta);
        }
        for (int i = 0; i < GUI_SIZE; i++) {
            if (i != SLOT_INPUT && i != SLOT_AGENT && i != SLOT_OUTPUT) {
                inventory.setItem(i, border.clone());
            }
        }

        // 输入槽标签
        ItemStack labelInput = new ItemStack(Material.IRON_PICKAXE);
        ItemMeta labelInputMeta = labelInput.getItemMeta();
        if (labelInputMeta != null) {
            labelInputMeta.setDisplayName(ChatColor.AQUA + "放入需要修复的工具或装备");
            labelInput.setItemMeta(labelInputMeta);
        }
        inventory.setItem(0, labelInput);

        // 修补剂槽标签
        ItemStack labelAgent = new ItemStack(Material.NETHERITE_SCRAP);
        ItemMeta labelAgentMeta = labelAgent.getItemMeta();
        if (labelAgentMeta != null) {
            labelAgentMeta.setDisplayName(ChatColor.LIGHT_PURPLE + "放入修复材料");
            labelAgent.setItemMeta(labelAgentMeta);
        }
        inventory.setItem(2, labelAgent);

        // 输出槽标签
        ItemStack labelOutput = new ItemStack(Material.ANVIL);
        ItemMeta labelOutputMeta = labelOutput.getItemMeta();
        if (labelOutputMeta != null) {
            labelOutputMeta.setDisplayName(ChatColor.GREEN + "修复完成");
            labelOutput.setItemMeta(labelOutputMeta);
        }
        inventory.setItem(4, labelOutput);

        openRepairGUIs.put(player.getUniqueId(), inventory);
        player.openInventory(inventory);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        Inventory openInv = openRepairGUIs.get(player.getUniqueId());
        if (openInv == null || !event.getInventory().equals(openInv)) {
            return;
        }

        int slot = event.getRawSlot();

        // 阻止点击边框
        if (slot < GUI_SIZE && slot != SLOT_INPUT && slot != SLOT_AGENT && slot != SLOT_OUTPUT) {
            event.setCancelled(true);
            return;
        }

        // 点击输出槽 - 尝试修复
        if (slot == SLOT_OUTPUT) {
            event.setCancelled(true);
            attemptRepair(player, openInv);
            return;
        }

        // 允许在输入槽和自身背包之间移动物品
        if (plugin != null) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                checkAutoRepair(player, openInv);
            });
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        Inventory openInv = openRepairGUIs.get(player.getUniqueId());
        if (openInv == null || !event.getInventory().equals(openInv)) {
            return;
        }

        // 阻止拖拽到边框
        for (int slot : event.getRawSlots()) {
            if (slot < GUI_SIZE && slot != SLOT_INPUT && slot != SLOT_AGENT && slot != SLOT_OUTPUT) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }

        Inventory openInv = openRepairGUIs.remove(player.getUniqueId());
        if (openInv == null || !event.getInventory().equals(openInv)) {
            return;
        }

        // 关闭时将输入槽的物品还给玩家
        ItemStack inputItem = openInv.getItem(SLOT_INPUT);
        if (inputItem != null && inputItem.getType() != Material.AIR) {
            player.getInventory().addItem(inputItem);
        }
        ItemStack agentItem = openInv.getItem(SLOT_AGENT);
        if (agentItem != null && agentItem.getType() != Material.AIR) {
            player.getInventory().addItem(agentItem);
        }
        ItemStack outputItem = openInv.getItem(SLOT_OUTPUT);
        if (outputItem != null && outputItem.getType() != Material.AIR) {
            player.getInventory().addItem(outputItem);
        }
    }

    private void checkAutoRepair(Player player, Inventory inventory) {
        ItemStack input = inventory.getItem(SLOT_INPUT);
        ItemStack agent = inventory.getItem(SLOT_AGENT);

        if (input != null && input.getType() != Material.AIR &&
                agent != null && agent.getType() != Material.AIR &&
                isRepairMaterial(agent)) {
            attemptRepair(player, inventory);
        }
    }

    private void attemptRepair(Player player, Inventory inventory) {
        ItemStack input = inventory.getItem(SLOT_INPUT);
        ItemStack agent = inventory.getItem(SLOT_AGENT);

        if (input == null || input.getType() == Material.AIR) {
            player.sendMessage(ChatColor.RED + "请放入需要修复的工具或装备");
            return;
        }

        if (!hasDurability(input)) {
            player.sendMessage(ChatColor.RED + "该物品无法修复");
            return;
        }

        if (agent == null || agent.getType() == Material.AIR || !isRepairMaterial(agent)) {
            player.sendMessage(ChatColor.RED + "请放入修复材料（万能修补剂或胶水）");
            return;
        }

        ItemStack repairedItem = input.clone();
        ItemMeta meta = repairedItem.getItemMeta();

        if (!(meta instanceof Damageable damageable)) {
            return;
        }

        int currentDamage = damageable.getDamage();
        int maxDamage = repairedItem.getType().getMaxDurability();
        int repairAmount = getRepairAmount(agent);
        int newDamage = currentDamage - repairAmount;

        newDamage = Math.max(0, Math.min(newDamage, maxDamage));
        damageable.setDamage(newDamage);
        repairedItem.setItemMeta((ItemMeta) damageable);

        // 消耗一个修复材料
        if (agent.getAmount() > 1) {
            agent.setAmount(agent.getAmount() - 1);
        } else {
            inventory.setItem(SLOT_AGENT, null);
        }

        // 清空输入槽
        inventory.setItem(SLOT_INPUT, null);

        // 设置输出
        inventory.setItem(SLOT_OUTPUT, repairedItem);

        if (repairAmount > 0) {
            player.sendMessage(ChatColor.GREEN + "修复完成！耐久 +" + repairAmount);
        } else if (repairAmount < 0) {
            player.sendMessage(ChatColor.RED + "修复失败！耐久 " + repairAmount);
        } else {
            player.sendMessage(ChatColor.YELLOW + "修复无效！耐久无变化");
        }
    }

    private boolean isRepairMaterial(ItemStack item) {
        return RepairAgent.isRepairAgent(item) ||
                PoorGlue.isPoorGlue(item) ||
                CheapGlue.isCheapGlue(item) ||
                BrandGlue.isBrandGlue(item);
    }

    private int getRepairAmount(ItemStack glue) {
        if (RepairAgent.isRepairAgent(glue)) {
            return getMaxDurability(glue);
        } else if (PoorGlue.isPoorGlue(glue)) {
            return PoorGlue.getRepairAmount();
        } else if (CheapGlue.isCheapGlue(glue)) {
            return CheapGlue.getRepairAmount();
        } else if (BrandGlue.isBrandGlue(glue)) {
            return BrandGlue.getRepairAmount();
        }
        return 0;
    }

    private int getMaxDurability(ItemStack item) {
        return item.getType().getMaxDurability();
    }

    private boolean hasDurability(ItemStack item) {
        return item.getItemMeta() instanceof Damageable;
    }

    private int getDamage(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta instanceof Damageable damageable) {
            return damageable.getDamage();
        }
        return 0;
    }

    private static class RepairHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}