package com.win9xplugin.gui;

import com.win9xplugin.weapons.Backpack;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BackpackGUI implements Listener {

    private static final Map<UUID, Inventory> openBackpacks = new HashMap<>();
    private static final Map<UUID, ItemStack> openBackpackItems = new HashMap<>();
    private static JavaPlugin plugin;
    private static NamespacedKey itemsKey;

    public static void setPlugin(JavaPlugin pl) {
        plugin = pl;
        itemsKey = new NamespacedKey(pl, "backpack_items");
    }

    public static void openBackpack(Player player, ItemStack backpack) {
        if (!Backpack.isBackpack(backpack)) {
            return;
        }

        int size = Backpack.getBackpackSize(backpack);
        String name = Backpack.getBackpackName(backpack);
        if (name == null) {
            name = "便携式背包";
        }

        Inventory inv = Bukkit.createInventory(player, size, ChatColor.GOLD + "" + ChatColor.BOLD + name);

        ItemStack[] storedItems = loadItems(backpack);
        if (storedItems != null) {
            for (int i = 0; i < storedItems.length && i < size; i++) {
                if (storedItems[i] != null) {
                    inv.setItem(i, storedItems[i]);
                }
            }
        }

        openBackpacks.put(player.getUniqueId(), inv);
        openBackpackItems.put(player.getUniqueId(), backpack);
        player.openInventory(inv);
    }

    private static ItemStack[] loadItems(ItemStack backpack) {
        if (!backpack.hasItemMeta()) {
            return null;
        }

        ItemMeta meta = backpack.getItemMeta();
        if (meta == null) {
            return null;
        }

        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(itemsKey, PersistentDataType.BYTE_ARRAY)) {
            return null;
        }

        byte[] data = container.get(itemsKey, PersistentDataType.BYTE_ARRAY);
        if (data == null) {
            return null;
        }

        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
            BukkitObjectInputStream dataInput = new BukkitObjectInputStream(inputStream);
            ItemStack[] items = new ItemStack[dataInput.readInt()];

            for (int i = 0; i < items.length; i++) {
                items[i] = (ItemStack) dataInput.readObject();
            }

            dataInput.close();
            return items;
        } catch (IOException | ClassNotFoundException e) {
            if (plugin != null) {
                plugin.getLogger().severe("加载背包物品失败: " + e.getMessage());
            }
            return null;
        }
    }

    private static void saveItems(ItemStack backpack, ItemStack[] items) {
        if (!backpack.hasItemMeta()) {
            return;
        }

        ItemMeta meta = backpack.getItemMeta();
        if (meta == null) {
            return;
        }

        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(outputStream);

            dataOutput.writeInt(items.length);
            for (ItemStack item : items) {
                dataOutput.writeObject(item);
            }

            dataOutput.close();

            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(itemsKey, PersistentDataType.BYTE_ARRAY, outputStream.toByteArray());
            backpack.setItemMeta(meta);
        } catch (IOException e) {
            if (plugin != null) {
                plugin.getLogger().severe("保存背包物品失败: " + e.getMessage());
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }

        Inventory inv = openBackpacks.remove(player.getUniqueId());
        if (inv == null) {
            return;
        }

        ItemStack backpack = openBackpackItems.remove(player.getUniqueId());
        if (backpack == null || !Backpack.isBackpack(backpack)) {
            return;
        }

        ItemStack[] items = inv.getContents();
        saveItems(backpack, items);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (!openBackpacks.containsKey(player.getUniqueId())) {
            return;
        }

        if (event.getClickedInventory() == player.getInventory()) {
            ItemStack clicked = event.getCurrentItem();
            if (clicked != null && Backpack.isBackpack(clicked)) {
                event.setCancelled(true);
            }
        }
    }
}