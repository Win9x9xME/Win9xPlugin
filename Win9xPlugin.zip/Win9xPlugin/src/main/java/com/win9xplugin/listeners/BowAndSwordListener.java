package com.win9xplugin.listeners;

import com.win9xplugin.weapons.ElementalBow;
import com.win9xplugin.weapons.ElementalSword;
import com.win9xplugin.weapons.PhoenixBow;
import com.win9xplugin.weapons.PhoenixSword;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Arrow;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Random;
import java.util.UUID;

public class BowAndSwordListener implements Listener {

    private final JavaPlugin plugin;
    private final Random random = new Random();

    public BowAndSwordListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBowShoot(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        ItemStack bow = event.getBow();
        if (bow == null) {
            return;
        }

        if (PhoenixBow.isPhoenixBow(bow)) {
            if (event.getProjectile() instanceof Arrow arrow) {
                arrow.setMetadata("phoenix_bow", new FixedMetadataValue(plugin, player.getUniqueId()));
                arrow.setFireTicks(100);

                player.getWorld().spawnParticle(
                        Particle.FLAME,
                        player.getEyeLocation(),
                        15, 0.3, 0.3, 0.3, 0.05
                );
                player.playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.0f, 1.0f);
            }
        } else if (ElementalBow.isElementalBow(bow)) {
            if (event.getProjectile() instanceof Arrow arrow) {
                arrow.setMetadata("elemental_bow", new FixedMetadataValue(plugin, player.getUniqueId()));
                String element = getRandomElement();
                arrow.setMetadata("element_type", new FixedMetadataValue(plugin, element));

                player.getWorld().spawnParticle(
                        Particle.ENCHANT,
                        player.getEyeLocation(),
                        15, 0.3, 0.3, 0.3, 0.05
                );
                player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);
                player.sendMessage(ChatColor.DARK_PURPLE + "元素之弓激活：" + ChatColor.YELLOW + getElementDisplayName(element));
            }
        }
    }

    @EventHandler
    public void onArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) {
            return;
        }

        if (!(event.getHitEntity() instanceof LivingEntity target)) {
            return;
        }

        if (arrow.hasMetadata("phoenix_bow")) {
            target.setFireTicks(100);

            target.getWorld().spawnParticle(
                    Particle.FLAME,
                    target.getLocation().add(0, 1, 0),
                    20, 0.5, 0.5, 0.5, 0.1
            );
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);

            if (target instanceof Player player) {
                player.sendMessage(ChatColor.GOLD + "你被凤凰之弓点燃了！");
            }
        } else if (arrow.hasMetadata("elemental_bow")) {
            String element = arrow.getMetadata("element_type").get(0).asString();
            applyElementEffect(target, element);
        }

        arrow.remove();
    }

    @EventHandler
    public void onSwordAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }

        if (!(event.getEntity() instanceof LivingEntity target)) {
            return;
        }

        ItemStack weapon = player.getInventory().getItemInMainHand();
        if (weapon == null || weapon.getType() == Material.AIR) {
            return;
        }

        if (PhoenixSword.isPhoenixSword(weapon)) {
            target.setFireTicks(100);

            player.getWorld().spawnParticle(
                    Particle.FLAME,
                    target.getLocation().add(0, 1, 0),
                    15, 0.3, 0.5, 0.3, 0.05
            );
            player.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);
            player.sendMessage(ChatColor.GOLD + "凤凰之剑点燃目标！");
        } else if (ElementalSword.isElementalSword(weapon)) {
            String element = getRandomElement();
            applyElementEffect(target, element);
            player.sendMessage(ChatColor.DARK_PURPLE + "元素之剑激活：" + ChatColor.YELLOW + getElementDisplayName(element));
        }
    }

    private String getRandomElement() {
        String[] elements = {"water", "earth", "fire", "air"};
        return elements[random.nextInt(elements.length)];
    }

    private String getElementDisplayName(String element) {
        switch (element) {
            case "water":
                return "水元素";
            case "earth":
                return "土元素";
            case "fire":
                return "火元素";
            case "air":
                return "气元素";
            default:
                return "未知元素";
        }
    }

    private void applyElementEffect(LivingEntity target, String element) {
        switch (element) {
            case "water":
                Vector knockback = target.getVelocity().multiply(2.0);
                knockback.setY(0.8);
                target.setVelocity(knockback);

                target.getWorld().spawnParticle(
                        Particle.SNOWFLAKE,
                        target.getLocation().add(0, 1, 0),
                        15, 0.3, 0.5, 0.3, 0.05
                );
                target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1.0f, 1.0f);
                break;

            case "earth":
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 3, true, false));

                target.getWorld().spawnParticle(
                        Particle.BLOCK,
                        target.getLocation().add(0, 1, 0),
                        15, 0.3, 0.5, 0.3, 0.05
                );
                target.getWorld().playSound(target.getLocation(), Sound.BLOCK_STONE_BREAK, 1.0f, 1.0f);
                break;

            case "fire":
                target.setFireTicks(100);

                target.getWorld().spawnParticle(
                        Particle.FLAME,
                        target.getLocation().add(0, 1, 0),
                        15, 0.3, 0.5, 0.3, 0.05
                );
                target.getWorld().playSound(target.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);
                break;

            case "air":
                target.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 1, true, false));

                target.getWorld().spawnParticle(
                        Particle.CLOUD,
                        target.getLocation().add(0, 1, 0),
                        15, 0.3, 0.5, 0.3, 0.05
                );
                target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1.0f, 1.0f);
                break;
        }

        if (target instanceof Player player) {
            player.sendMessage(ChatColor.DARK_PURPLE + "你被" + getElementDisplayName(element) + "效果影响了！");
        }
    }
}