package com.win9xplugin.listeners;

import com.win9xplugin.weapons.ChainPickaxe;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ChainMiningListener implements Listener {

    private static final int MAX_CHAIN_BLOCKS = 64;
    private final Set<Block> breakingBlocks = new HashSet<>();
    private final Object breakingLock = new Object();

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        ItemStack tool = event.getPlayer().getInventory().getItemInMainHand();
        
        if (!ChainPickaxe.isChainPickaxe(tool)) {
            return;
        }

        Block brokenBlock = event.getBlock();
        
        synchronized (breakingLock) {
            if (breakingBlocks.contains(brokenBlock)) {
                return;
            }
        }

        Material blockType = brokenBlock.getType();

        if (!isOre(blockType)) {
            return;
        }

        Set<Block> blocksToBreak = findConnectedOres(brokenBlock, blockType);
        blocksToBreak.remove(brokenBlock);

        for (Block block : blocksToBreak) {
            if (block.getLocation().equals(brokenBlock.getLocation())) {
                continue;
            }
            synchronized (breakingLock) {
                if (breakingBlocks.contains(block)) {
                    continue;
                }
                breakingBlocks.add(block);
            }
            block.breakNaturally(tool);
            synchronized (breakingLock) {
                breakingBlocks.remove(block);
            }
        }
    }

    private boolean isOre(Material material) {
        return material == Material.COAL_ORE ||
               material == Material.DEEPSLATE_COAL_ORE ||
               material == Material.IRON_ORE ||
               material == Material.DEEPSLATE_IRON_ORE ||
               material == Material.GOLD_ORE ||
               material == Material.DEEPSLATE_GOLD_ORE ||
               material == Material.DIAMOND_ORE ||
               material == Material.DEEPSLATE_DIAMOND_ORE ||
               material == Material.REDSTONE_ORE ||
               material == Material.DEEPSLATE_REDSTONE_ORE ||
               material == Material.LAPIS_ORE ||
               material == Material.DEEPSLATE_LAPIS_ORE ||
               material == Material.COPPER_ORE ||
               material == Material.DEEPSLATE_COPPER_ORE ||
               material == Material.EMERALD_ORE ||
               material == Material.DEEPSLATE_EMERALD_ORE ||
               material == Material.NETHER_GOLD_ORE ||
               material == Material.NETHER_QUARTZ_ORE ||
               material == Material.ANCIENT_DEBRIS;
    }

    private Set<Block> findConnectedOres(Block startBlock, Material oreType) {
        Set<Block> result = new HashSet<>();
        List<Block> toCheck = new ArrayList<>();
        Set<Block> checked = new HashSet<>();

        toCheck.add(startBlock);

        while (!toCheck.isEmpty() && result.size() < MAX_CHAIN_BLOCKS) {
            Block current = toCheck.remove(0);
            
            if (checked.contains(current)) {
                continue;
            }
            
            checked.add(current);

            if (current.getType() == oreType) {
                result.add(current);

                for (int dx = -1; dx <= 1; dx++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx == 0 && dy == 0 && dz == 0) {
                                continue;
                            }
                            Block neighbor = current.getRelative(dx, dy, dz);
                            if (!checked.contains(neighbor) && neighbor.getType() == oreType) {
                                toCheck.add(neighbor);
                            }
                        }
                    }
                }
            }
        }

        return result;
    }
}