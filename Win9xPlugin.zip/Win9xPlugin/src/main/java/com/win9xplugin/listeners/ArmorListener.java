package com.win9xplugin.listeners;

import com.win9xplugin.weapons.ElementalArmor;
import com.win9xplugin.weapons.PhoenixArmor;
import org.bukkit.Particle;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class ArmorListener implements Listener {

    private final JavaPlugin plugin;

    public ArmorListener(JavaPlugin plugin) {
        this.plugin = plugin;
        startArmorTask();
    }

    private void startArmorTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    int phoenixArmorCount = PhoenixArmor.countEquippedPhoenixArmor(player);
                    double maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
                    if (phoenixArmorCount > 0 && player.getHealth() < maxHealth) {
                        double healAmount = phoenixArmorCount * 1.0;
                        double newHealth = Math.min(player.getHealth() + healAmount, maxHealth);
                        player.setHealth(newHealth);

                        player.getWorld().spawnParticle(
                                Particle.HEART,
                                player.getLocation().add(0, 1.5, 0),
                                phoenixArmorCount * 2, 0.3, 0.5, 0.3, 0.1
                        );
                    }

                    int elementalArmorCount = countEquippedElementalArmor(player);
                    if (elementalArmorCount > 0) {
                        applyElementalBuffs(player);
                    } else {
                        removeElementalBuffs(player);
                    }
                }
            }
        }.runTaskTimer(plugin, 0, 10);
    }

    private void applyElementalBuffs(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 40, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 40, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 40, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 0, true, false));
    }

    private void removeElementalBuffs(Player player) {
        player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        player.removePotionEffect(PotionEffectType.RESISTANCE);
        player.removePotionEffect(PotionEffectType.REGENERATION);
    }

    private int countEquippedElementalArmor(Player player) {
        int count = 0;
        if (ElementalArmor.isElementalArmor(player.getInventory().getHelmet())) count++;
        if (ElementalArmor.isElementalArmor(player.getInventory().getChestplate())) count++;
        if (ElementalArmor.isElementalArmor(player.getInventory().getLeggings())) count++;
        if (ElementalArmor.isElementalArmor(player.getInventory().getBoots())) count++;
        return count;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        int phoenixArmorCount = PhoenixArmor.countEquippedPhoenixArmor(player);
        if (phoenixArmorCount > 0) {
            player.sendMessage(org.bukkit.ChatColor.GOLD + "凤凰铠甲效果激活！每秒恢复 " + phoenixArmorCount + " 点生命值");
        }

        int elementalArmorCount = countEquippedElementalArmor(player);
        if (elementalArmorCount > 0) {
            player.sendMessage(org.bukkit.ChatColor.DARK_PURPLE + "元素铠甲效果激活！获得水下呼吸、抗火、抗性提升、生命恢复效果");
            applyElementalBuffs(player);
        }
    }
}
