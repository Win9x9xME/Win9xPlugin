package com.win9xplugin.listeners;

import com.win9xplugin.unlock.UnlockData;
import com.win9xplugin.unlock.UnlockItem;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CraftListener implements Listener {

    private final NamespacedKey weaponKey;
    private static final Map<UUID, String> craftFailMessages = new HashMap<>();

    public CraftListener(NamespacedKey namespacedKey) {
        this.weaponKey = namespacedKey;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (!(event.getView().getPlayer() instanceof Player player)) {
            return;
        }

        ItemStack[] matrix = event.getInventory().getMatrix();

        for (ItemStack item : matrix) {
            if (isCustomItem(item)) {
                String itemId = getItemId(item);

                if (itemId != null && UnlockItem.isUnlockable(itemId) && !UnlockData.isUnlocked(player, itemId)) {
                    event.getInventory().setResult(null);
                    craftFailMessages.put(player.getUniqueId(), "【" + UnlockItem.getDisplayName(itemId) + "】尚未研究，无法使用！");
                    return;
                }

                ItemStack result = event.getInventory().getResult();
                if (result != null && isCustomItem(result)) {
                    String resultId = getItemId(result);

                    if (resultId != null && UnlockItem.isUnlockable(resultId) && !UnlockData.isUnlocked(player, resultId)) {
                        event.getInventory().setResult(null);
                        craftFailMessages.put(player.getUniqueId(), "【" + UnlockItem.getDisplayName(resultId) + "】尚未研究，无法合成！");
                        return;
                    }

                    return;
                }

                event.getInventory().setResult(null);
                return;
            }
        }
    }

    public static String getCraftFailMessage(Player player) {
        return craftFailMessages.remove(player.getUniqueId());
    }

    private boolean isCustomItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(weaponKey, PersistentDataType.STRING);
    }

    private String getItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(weaponKey, PersistentDataType.STRING)) {
            return null;
        }
        return container.get(weaponKey, PersistentDataType.STRING);
    }
}