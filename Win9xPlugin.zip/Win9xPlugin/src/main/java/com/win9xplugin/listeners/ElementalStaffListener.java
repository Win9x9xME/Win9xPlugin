package com.win9xplugin.listeners;

import com.win9xplugin.weapons.ElementalStaff;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ElementalStaffListener implements Listener {

    private static final Map<UUID, Long> cooldowns = new HashMap<>();
    private static final long COOLDOWN_TIME = 34 * 1000L;
    private static final long EFFECT_DURATION = 10 * 1000L;

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (item == null || item.getType() == Material.AIR) {
            return;
        }

        if (!ElementalStaff.isElementalStaff(item)) {
            return;
        }

        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        event.setCancelled(true);

        if (isOnCooldown(player)) {
            long remaining = getRemainingCooldown(player);
            if (remaining > COOLDOWN_TIME - EFFECT_DURATION) {
                player.sendMessage(ChatColor.YELLOW + "元素法杖效果生效中……");
            } else {
                player.sendMessage(ChatColor.RED + "元素法杖冷却中，剩余 " + (remaining / 1000) + " 秒");
            }
            return;
        }

        applyBuffs(player);
        setCooldown(player);
        player.sendMessage(ChatColor.GREEN + "你获得了元素祝福！所有正面buff 1级效果持续10秒");
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }

        ItemStack item = player.getInventory().getItemInMainHand();

        if (item == null || item.getType() == Material.AIR) {
            return;
        }

        if (!ElementalStaff.isElementalStaff(item)) {
            return;
        }

        event.setDamage(event.getDamage() + 2.0);
    }

    private void applyBuffs(Player player) {
        // 清除旧的效果再添加新效果，防止叠加
        clearBuffs(player);
        
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, 200, 0, true, false));
    }

    private void clearBuffs(Player player) {
        player.removePotionEffect(PotionEffectType.SPEED);
        player.removePotionEffect(PotionEffectType.JUMP_BOOST);
        player.removePotionEffect(PotionEffectType.HASTE);
        player.removePotionEffect(PotionEffectType.REGENERATION);
        player.removePotionEffect(PotionEffectType.RESISTANCE);
        player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        player.removePotionEffect(PotionEffectType.NIGHT_VISION);
        player.removePotionEffect(PotionEffectType.ABSORPTION);
        player.removePotionEffect(PotionEffectType.HEALTH_BOOST);
        player.removePotionEffect(PotionEffectType.STRENGTH);
        player.removePotionEffect(PotionEffectType.LUCK);
    }

    private boolean isOnCooldown(Player player) {
        if (!cooldowns.containsKey(player.getUniqueId())) {
            return false;
        }
        long lastUse = cooldowns.get(player.getUniqueId());
        return System.currentTimeMillis() - lastUse < COOLDOWN_TIME;
    }

    private long getRemainingCooldown(Player player) {
        if (!cooldowns.containsKey(player.getUniqueId())) {
            return 0;
        }
        long lastUse = cooldowns.get(player.getUniqueId());
        return COOLDOWN_TIME - (System.currentTimeMillis() - lastUse);
    }

    private void setCooldown(Player player) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }
}