package com.win9xplugin.listeners;

import com.win9xplugin.weapons.GuideBook;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class GuideBookListener implements Listener {

    private final JavaPlugin plugin;

    public GuideBookListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (!plugin.getConfig().getBoolean("auto-give-guide.enabled", true)) {
            return;
        }

        if (player.hasPlayedBefore()) {
            return;
        }

        ItemStack guideBook = GuideBook.createGuideBook();
        player.getInventory().addItem(guideBook);

        String message = plugin.getConfig().getString("auto-give-guide.message", "&6欢迎加入服务器！你获得了 Win9xPlugin 指南书！");
        player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));

        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }
}