package com.win9xplugin.listeners;

import com.win9xplugin.gui.RepairGUI;
import com.win9xplugin.weapons.WPRepairMachine;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class RepairListener implements Listener {

    private static JavaPlugin plugin;

    public static void setPlugin(JavaPlugin pl) {
        plugin = pl;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (item == null || item.getType().isAir()) {
            item = player.getInventory().getItemInMainHand();
            if (item == null || item.getType().isAir()) {
                item = player.getInventory().getItemInOffHand();
                if (item == null || item.getType().isAir()) {
                    return;
                }
            }
        }

        if (WPRepairMachine.isWPRepairMachine(item)) {
            event.setCancelled(true);
            RepairGUI.openRepairGUI(player);
        }
    }
}