package com.win9xplugin.listeners;

import com.win9xplugin.Win9xPlugin;
import com.win9xplugin.weapons.PhoenixStaff;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class WeaponListener implements Listener {

    private final Random random = new Random();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Long> charging = new HashMap<>();
    private final Map<UUID, BukkitRunnable> chargeTasks = new HashMap<>();
    private static final long COOLDOWN_MS = 3500; // 3.5秒冷却
    private static final long MAX_CHARGE_MS = 3000; // 最大蓄力时间3秒
    private Win9xPlugin plugin;

    public WeaponListener(Win9xPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }

        if (!(event.getEntity() instanceof LivingEntity target)) {
            return;
        }

        if (!PhoenixStaff.isPhoenixStaff(player.getInventory().getItemInMainHand())) {
            return;
        }

        double originalDamage = event.getDamage();
        boolean isCrit = random.nextDouble() < 0.25;

        if (isCrit) {
            event.setDamage(originalDamage * 2.0);
            target.setFireTicks(100);
            player.getWorld().spawnParticle(
                    Particle.EXPLOSION,
                    target.getLocation().add(0, 1, 0),
                    5, 0.5, 0.5, 0.5, 0.1
            );
            player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.5f);
            player.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "烈焰暴击！ 造成 " +
                    ChatColor.RED + Math.round(originalDamage * 2.0) + ChatColor.GOLD + " 点伤害！");
        }

        double damage = event.getFinalDamage();
        double healAmount = damage * 0.30;
        double maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        double newHealth = Math.min(player.getHealth() + healAmount, maxHealth);
        player.setHealth(newHealth);

        player.getWorld().spawnParticle(
                Particle.HEART,
                player.getLocation().add(0, 1, 0),
                3, 0.3, 0.3, 0.3, 0.1
        );

        double radius = 3.0;
        Collection<Entity> nearbyEntities = target.getNearbyEntities(radius, radius, radius);
        for (Entity entity : nearbyEntities) {
            if (entity instanceof LivingEntity nearby && entity != player && entity != target) {
                nearby.damage(damage * 0.5, player);
                nearby.getWorld().spawnParticle(
                        Particle.FLAME,
                        nearby.getLocation().add(0, 1, 0),
                        8, 0.3, 0.5, 0.3, 0.05
                );
            }
        }

        player.getWorld().spawnParticle(
                Particle.FLAME,
                target.getLocation().add(0, 1, 0),
                10, 0.3, 0.5, 0.3, 0.05
        );
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        if (!PhoenixStaff.isPhoenixStaff(player.getInventory().getItemInMainHand())) {
            return;
        }

        event.setCancelled(true);
        UUID playerId = player.getUniqueId();

        // 检查冷却
        if (cooldowns.containsKey(playerId)) {
            long lastUse = cooldowns.get(playerId);
            long elapsed = System.currentTimeMillis() - lastUse;
            if (elapsed < COOLDOWN_MS) {
                long remaining = (COOLDOWN_MS - elapsed) / 1000;
                player.sendMessage(ChatColor.RED + "冷却中... " + remaining + "秒");
                return;
            }
        }

        // 如果已经在蓄力中，释放冲击波
        if (charging.containsKey(playerId)) {
            releaseFireWave(player);
            return;
        }

        // 开始蓄力
        startCharging(player);
    }

    private void startCharging(Player player) {
        UUID playerId = player.getUniqueId();
        charging.put(playerId, System.currentTimeMillis());

        // 创建蓄力任务
        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!charging.containsKey(playerId)) {
                    cancel();
                    return;
                }

                // 检查玩家是否还持有法杖
                if (!PhoenixStaff.isPhoenixStaff(player.getInventory().getItemInMainHand())) {
                    cancelCharging(player);
                    cancel();
                    return;
                }

                long chargeTime = System.currentTimeMillis() - charging.get(playerId);
                float chargePercent = Math.min(1.0f, chargeTime / (float) MAX_CHARGE_MS);

                // 使用经验条显示蓄力进度
                player.setLevel((int) (chargePercent * 100));
                player.setExp(chargePercent);

                // 蓄力粒子效果
                Location loc = player.getLocation().add(0, 1, 0);
                player.getWorld().spawnParticle(
                        Particle.FLAME,
                        loc,
                        (int) (3 + chargePercent * 10),
                        0.3, 0.3, 0.3, 0.02
                );

                // 蓄力满后自动释放
                if (chargeTime >= MAX_CHARGE_MS) {
                    releaseFireWave(player);
                    cancel();
                }
            }
        };
        task.runTaskTimer(plugin, 0, 4); // 每4tick更新一次
        chargeTasks.put(playerId, task);

        player.sendMessage(ChatColor.YELLOW + "正在蓄力...");
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 0.5f, 1.0f);
    }

    private void releaseFireWave(Player player) {
        UUID playerId = player.getUniqueId();

        // 计算蓄力程度
        long chargeTime = charging.containsKey(playerId) ?
                System.currentTimeMillis() - charging.get(playerId) : 0;
        float chargePercent = Math.min(1.0f, chargeTime / (float) MAX_CHARGE_MS);

        // 清理蓄力状态
        charging.remove(playerId);
        if (chargeTasks.containsKey(playerId)) {
            chargeTasks.get(playerId).cancel();
            chargeTasks.remove(playerId);
        }

        // 重置经验条显示
        player.setLevel(0);
        player.setExp(0);

        // 设置冷却
        cooldowns.put(playerId, System.currentTimeMillis());

        // 根据蓄力程度计算效果
        double damage = 10.0 + chargePercent * 20.0; // 10-30伤害
        double range = 5.0 + chargePercent * 8.0; // 5-13范围
        double explosionRadius = 2.0 + chargePercent * 4.0; // 2-6爆炸半径
        double knockbackStrength = 1.0 + chargePercent * 2.0; // 1-3击退力度
        int fireTicks = (int) (40 + chargePercent * 100); // 40-140燃烧时间

        Location eyeLocation = player.getEyeLocation();
        Vector direction = eyeLocation.getDirection().normalize();

        // 音效根据蓄力程度变化
        float pitch = 0.8f + chargePercent * 0.6f;
        player.getWorld().playSound(player.getLocation(), Sound.ITEM_FIRECHARGE_USE, 1.0f + chargePercent, pitch);

        // 粒子轨迹
        int particleCount = (int) (10 + chargePercent * 30);
        for (int i = 0; i < particleCount; i++) {
            Location particleLoc = eyeLocation.clone().add(direction.clone().multiply(i * 0.6));
            player.getWorld().spawnParticle(
                    Particle.FLAME,
                    particleLoc,
                    (int) (3 + chargePercent * 8),
                    0.4, 0.4, 0.4, 0.02 + chargePercent * 0.05
            );
            player.getWorld().spawnParticle(
                    Particle.SMOKE,
                    particleLoc,
                    (int) (1 + chargePercent * 3),
                    0.3, 0.3, 0.3, 0.02
            );
        }

        // 寻找目标并爆炸
        for (double t = 0; t < range; t += 0.5) {
            Location checkLoc = eyeLocation.clone().add(direction.clone().multiply(t));
            Collection<Entity> entities = checkLoc.getWorld().getNearbyEntities(checkLoc, 1, 1, 1);
            boolean hit = false;

            for (Entity entity : entities) {
                if (entity instanceof LivingEntity && entity != player) {
                    hit = true;
                    break;
                }
            }

            if (hit || t >= range - 0.5) {
                Location impactLoc = checkLoc;

                impactLoc.getWorld().createExplosion(
                        impactLoc,
                        0.0f,
                        false,
                        false,
                        player
                );

                // 爆炸粒子效果根据蓄力程度增强
                impactLoc.getWorld().spawnParticle(
                        Particle.EXPLOSION_EMITTER,
                        impactLoc,
                        (int) (1 + chargePercent * 3),
                        0.5, 0.5, 0.5, 0.1
                );
                impactLoc.getWorld().spawnParticle(
                        Particle.FLAME,
                        impactLoc,
                        (int) (20 + chargePercent * 50),
                        explosionRadius / 2, explosionRadius / 2, explosionRadius / 2, 0.1
                );
                impactLoc.getWorld().playSound(impactLoc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f + chargePercent, 1.0f);

                Collection<Entity> nearbyEntities = impactLoc.getWorld().getNearbyEntities(
                        impactLoc, explosionRadius, explosionRadius, explosionRadius
                );

                for (Entity entity : nearbyEntities) {
                    if (entity instanceof LivingEntity target && entity != player) {
                        target.damage(damage, player);
                        target.setFireTicks(fireTicks);

                        Vector knockback = target.getLocation().toVector()
                                .subtract(impactLoc.toVector()).normalize().multiply(knockbackStrength);
                        knockback.setY(0.5 + chargePercent * 0.8);
                        target.setVelocity(knockback);
                    }
                }
                break;
            }
        }

        // 显示释放信息
        String chargeLevel = chargePercent < 0.33 ? "弱" : (chargePercent < 0.66 ? "中" : "强");
        ChatColor chargeColor = chargePercent < 0.33 ? ChatColor.YELLOW :
                (chargePercent < 0.66 ? ChatColor.GOLD : ChatColor.RED);
        player.sendMessage(chargeColor + "火焰冲击波释放！ [" + chargeLevel + "] 伤害: " + Math.round(damage));
    }

    private void cancelCharging(Player player) {
        UUID playerId = player.getUniqueId();
        charging.remove(playerId);
        if (chargeTasks.containsKey(playerId)) {
            chargeTasks.get(playerId).cancel();
            chargeTasks.remove(playerId);
        }
        player.setLevel(0);
        player.setExp(0);
        player.sendMessage(ChatColor.GRAY + "蓄力取消");
    }

    // 切换物品时取消蓄力
    @EventHandler
    public void onItemChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        if (charging.containsKey(playerId)) {
            cancelCharging(player);
        }
    }

    // 玩家退出时清理数据
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        charging.remove(playerId);
        cooldowns.remove(playerId);
        if (chargeTasks.containsKey(playerId)) {
            chargeTasks.get(playerId).cancel();
            chargeTasks.remove(playerId);
        }
    }
}
