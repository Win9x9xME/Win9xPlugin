package com.win9xplugin.listeners;

import com.win9xplugin.gui.TrashCanGUI;
import com.win9xplugin.weapons.TrashCan;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;

public class TrashCanListener implements Listener {

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        if (TrashCan.isTrashCan(player.getInventory().getItemInMainHand()) ||
            TrashCan.isTrashCan(player.getInventory().getItemInOffHand())) {
            event.setCancelled(true);
            TrashCanGUI.openTrashCan(player);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        Player player = (Player) event.getPlayer();
        if (event.getView().getTitle().contains("垃圾桶")) {
            // 清空垃圾桶内容
            Inventory inventory = event.getInventory();
            for (int i = 0; i < inventory.getSize(); i++) {
                inventory.setItem(i, null);
            }
        }
    }
}
