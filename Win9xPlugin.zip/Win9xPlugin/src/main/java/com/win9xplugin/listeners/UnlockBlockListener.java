package com.win9xplugin.listeners;

import com.win9xplugin.unlock.UnlockData;
import com.win9xplugin.unlock.UnlockItem;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class UnlockBlockListener implements Listener {

    private static NamespacedKey weaponKey;
    private static JavaPlugin plugin;
    private static final Map<UUID, Long> cooldowns = new HashMap<>();
    private static final long COOLDOWN_TIME = 2000;

    public static void setPlugin(JavaPlugin pl) {
        plugin = pl;
    }

    public static void setKey(org.bukkit.NamespacedKey key) {
        weaponKey = key;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (event.getAction() == Action.LEFT_CLICK_BLOCK || event.getAction() == Action.LEFT_CLICK_AIR) {
            return;
        }

        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }

        ItemStack item = event.getItem();
        if (item == null) {
            item = player.getInventory().getItemInMainHand();
        }

        if (item == null || item.getType().isAir()) {
            return;
        }

        String itemId = getItemId(item);
        if (itemId == null) {
            return;
        }

        if (!UnlockItem.isUnlockable(itemId)) {
            return;
        }

        if (UnlockData.isUnlocked(player, itemId)) {
            return;
        }

        if (!canSendMessage(player)) {
            return;
        }

        event.setCancelled(true);
        event.setUseItemInHand(Event.Result.DENY);
        player.sendMessage(ChatColor.RED + "【" + UnlockItem.getDisplayName(itemId) + "】尚未研究！");
        player.sendMessage(ChatColor.GRAY + "请先在研究界面解锁该物品");
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItemInHand();

        if (item == null || item.getType().isAir()) {
            return;
        }

        String itemId = getItemId(item);
        if (itemId == null) {
            return;
        }

        if (!UnlockItem.isUnlockable(itemId)) {
            return;
        }

        if (UnlockData.isUnlocked(player, itemId)) {
            return;
        }

        event.setCancelled(true);
        player.sendMessage(ChatColor.RED + "【" + UnlockItem.getDisplayName(itemId) + "】尚未研究！");
        player.sendMessage(ChatColor.GRAY + "请先在研究界面解锁该物品");
    }

    private boolean canSendMessage(Player player) {
        UUID uuid = player.getUniqueId();
        if (!cooldowns.containsKey(uuid)) {
            return true;
        }
        long lastTime = cooldowns.get(uuid);
        return System.currentTimeMillis() - lastTime > COOLDOWN_TIME;
    }

    private String getItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        if (weaponKey == null) {
            return null;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(weaponKey, PersistentDataType.STRING)) {
            return null;
        }
        return container.get(weaponKey, PersistentDataType.STRING);
    }
}
