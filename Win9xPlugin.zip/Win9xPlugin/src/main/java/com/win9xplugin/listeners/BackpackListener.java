package com.win9xplugin.listeners;

import com.win9xplugin.gui.BackpackGUI;
import com.win9xplugin.weapons.Backpack;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class BackpackListener implements Listener {

    private final JavaPlugin plugin;
    private final Set<Player> playersNamingBackpack = new HashSet<>();
    private final Map<Player, ItemStack> playerBackpackToName = new HashMap<>();

    public BackpackListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onRightClick(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        ItemStack item = event.getItem();

        if (item == null || item.getType().isAir()) {
            item = player.getInventory().getItemInMainHand();
            if (item == null || item.getType().isAir()) {
                item = player.getInventory().getItemInOffHand();
                if (item == null || item.getType().isAir()) {
                    return;
                }
            }
        }

        if (!Backpack.isBackpack(item)) {
            return;
        }

        event.setUseItemInHand(Event.Result.DENY);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setCancelled(true);

        if (Backpack.isNamed(item)) {
            BackpackGUI.openBackpack(player, item);
        } else {
            startNamingMode(player, item);
        }
    }

    private void startNamingMode(Player player, ItemStack item) {
        playersNamingBackpack.add(player);
        playerBackpackToName.put(player, item);
        player.sendMessage(ChatColor.YELLOW + "请在聊天栏输入背包名称：");
        player.sendMessage(ChatColor.GRAY + "(输入 cancel 取消命名)");

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (playersNamingBackpack.contains(player)) {
                playersNamingBackpack.remove(player);
                playerBackpackToName.remove(player);
                player.sendMessage(ChatColor.GRAY + "背包命名已超时");
            }
        }, 600);
    }

    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!playersNamingBackpack.contains(player)) {
            return;
        }

        event.setCancelled(true);
        String name = event.getMessage().trim();

        if (name.equalsIgnoreCase("cancel")) {
            playersNamingBackpack.remove(player);
            playerBackpackToName.remove(player);
            player.sendMessage(ChatColor.GRAY + "已取消命名");
            return;
        }

        if (name.isEmpty()) {
            player.sendMessage(ChatColor.RED + "名称不能为空，请重新输入");
            return;
        }

        ItemStack backpack = playerBackpackToName.get(player);
        if (backpack != null) {
            String type = Backpack.getBackpackType(backpack);
            String defaultName = "";
            if (Backpack.BACKPACK_SMALL.equals(type)) {
                defaultName = "初级背包";
            } else if (Backpack.BACKPACK_MEDIUM.equals(type)) {
                defaultName = "中级背包";
            } else if (Backpack.BACKPACK_LARGE.equals(type)) {
                defaultName = "高级背包";
            }

            String displayName = defaultName + " - " + name;
            Backpack.setBackpackName(backpack, displayName);

            player.sendMessage(ChatColor.GREEN + "背包已命名为：" + displayName);

            plugin.getServer().getScheduler().runTask(plugin, () -> {
                ItemStack mainHand = player.getInventory().getItemInMainHand();
                ItemStack offHand = player.getInventory().getItemInOffHand();
                if (Backpack.isBackpack(mainHand)) {
                    player.getInventory().setItemInMainHand(backpack);
                } else if (Backpack.isBackpack(offHand)) {
                    player.getInventory().setItemInOffHand(backpack);
                }
                BackpackGUI.openBackpack(player, backpack);
            });
        }

        playersNamingBackpack.remove(player);
        playerBackpackToName.remove(player);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        playersNamingBackpack.remove(player);
        playerBackpackToName.remove(player);
    }
}