package com.win9xplugin;

import com.win9xplugin.commands.Win9xPluginCommand;
import com.win9xplugin.gui.BackpackGUI;
import com.win9xplugin.gui.GuideGUI;
import com.win9xplugin.gui.RepairGUI;
import com.win9xplugin.gui.TrashCanGUI;
import com.win9xplugin.listeners.ArmorListener;
import com.win9xplugin.listeners.BackpackListener;
import com.win9xplugin.listeners.BowAndSwordListener;
import com.win9xplugin.listeners.ChainMiningListener;
import com.win9xplugin.listeners.CraftListener;
import com.win9xplugin.listeners.ElementalStaffListener;
import com.win9xplugin.listeners.GuideBookListener;
import com.win9xplugin.listeners.RepairListener;
import com.win9xplugin.listeners.TrashCanListener;
import com.win9xplugin.listeners.UnlockBlockListener;
import com.win9xplugin.listeners.WeaponListener;
import com.win9xplugin.unlock.UnlockData;
import com.win9xplugin.unlock.UnlockGUI;
import com.win9xplugin.unlock.UnlockItem;
import com.win9xplugin.weapons.Backpack;
import com.win9xplugin.weapons.BrandGlue;
import com.win9xplugin.weapons.CheapGlue;
import com.win9xplugin.weapons.ChainPickaxe;
import com.win9xplugin.weapons.ElementalArmor;
import com.win9xplugin.weapons.ElementalBow;
import com.win9xplugin.weapons.ElementalMaterials;
import com.win9xplugin.weapons.ElementalStaff;
import com.win9xplugin.weapons.ElementalSword;
import com.win9xplugin.weapons.GuideBook;
import com.win9xplugin.weapons.PhoenixArmor;
import com.win9xplugin.weapons.PhoenixBow;
import com.win9xplugin.weapons.PhoenixMaterials;
import com.win9xplugin.weapons.PhoenixStaff;
import com.win9xplugin.weapons.PhoenixSword;
import com.win9xplugin.weapons.PoorGlue;
import com.win9xplugin.weapons.RepairAgent;
import com.win9xplugin.weapons.TrashCan;
import com.win9xplugin.weapons.WPFurnace;
import com.win9xplugin.weapons.WPRepairMachine;
import com.win9xplugin.weapons.WPWorkbench;
import com.win9xplugin.utils.DebugLogger;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.recipe.CookingBookCategory;
import org.bukkit.inventory.recipe.CraftingBookCategory;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.plugin.java.JavaPlugin;

public class Win9xPlugin extends JavaPlugin {

    private static NamespacedKey weaponKey;

    public static NamespacedKey getWeaponKey() {
        return weaponKey;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();

        DebugLogger.init(this);
        if (DebugLogger.isDebugEnabled()) {
            DebugLogger.info("调试模式已启用！");
        }

        getLogger().info("Win9x的第一个Spigot插件 已加载成功！");

        weaponKey = new NamespacedKey(this, "weapon_id");
        PhoenixStaff.setKey(weaponKey);
        PhoenixArmor.setKey(weaponKey);
        PhoenixBow.setKey(weaponKey);
        PhoenixSword.setKey(weaponKey);
        WPWorkbench.setKey(weaponKey);
        WPFurnace.setKey(weaponKey);
        PhoenixMaterials.setKey(weaponKey);
        GuideBook.setKey(weaponKey);
        ElementalStaff.setKey(weaponKey);
        ElementalArmor.setKey(weaponKey);
        ElementalBow.setKey(weaponKey);
        ElementalSword.setKey(weaponKey);
        ElementalMaterials.setKey(weaponKey);
        Backpack.setKey(weaponKey);
        TrashCan.setKey(weaponKey);
        ChainPickaxe.setKey(weaponKey);
        RepairAgent.setKey(weaponKey);
        WPRepairMachine.setKey(weaponKey);
        PoorGlue.setKey(weaponKey);
        CheapGlue.setKey(weaponKey);
        BrandGlue.setKey(weaponKey);

        UnlockItem.init();
        UnlockData.init(this);
        UnlockBlockListener.setKey(weaponKey);
        UnlockBlockListener.setPlugin(this);

        getServer().getPluginManager().registerEvents(new WeaponListener(this), this);
        getServer().getPluginManager().registerEvents(new BackpackListener(this), this);
        getServer().getPluginManager().registerEvents(new BackpackGUI(), this);
        BackpackGUI.setPlugin(this);
        getServer().getPluginManager().registerEvents(new ArmorListener(this), this);
        getServer().getPluginManager().registerEvents(new ElementalStaffListener(), this);
        getServer().getPluginManager().registerEvents(new BowAndSwordListener(this), this);
        getServer().getPluginManager().registerEvents(new GuideGUI(this), this);
        getServer().getPluginManager().registerEvents(new GuideBookListener(this), this);
        getServer().getPluginManager().registerEvents(new CraftListener(weaponKey), this);
        getServer().getPluginManager().registerEvents(new TrashCanListener(), this);
        getServer().getPluginManager().registerEvents(new ChainMiningListener(), this);
        getServer().getPluginManager().registerEvents(new RepairGUI(), this);
        getServer().getPluginManager().registerEvents(new RepairListener(), this);
        RepairGUI.setPlugin(this);
        RepairListener.setPlugin(this);
        UnlockGUI.setPlugin(this);
        getServer().getPluginManager().registerEvents(new UnlockGUI(), this);
        TrashCanGUI.setPlugin(this);

        Win9xPluginCommand mainCommand = new Win9xPluginCommand(this);
        this.getCommand("win9xplugin").setExecutor(mainCommand);
        this.getCommand("win9xplugin").setTabCompleter(mainCommand);

        registerRecipes();

        getLogger().info("凤凰武器系统已启用！");
        getLogger().info("Win9xPlugin 指南已启用！");
    }

    @Override
    public void onDisable() {
        getLogger().info("Win9x的第一个Spigot插件 已禁用成功！");
    }

    private void registerRecipes() {
        registerWorkbenchRecipe();
        registerFurnaceRecipe();
        registerMaterialRecipes();
        registerFurnaceRecipes();
        registerStaffRecipe();
        registerBowRecipes();
        registerSwordRecipes();
        registerArmorRecipes();
        registerElementalMaterialRecipes();
        registerElementalArmorRecipes();
        registerElementalStaffRecipe();
        registerElementalBowRecipe();
        registerElementalSwordRecipe();
        registerGuideRecipe();
        registerBackpackRecipes();
        registerTrashCanRecipe();
        registerChainPickaxeRecipe();
        registerRepairMachineRecipe();
        registerRepairAgentRecipe();
        registerGlueRecipes();
    }

    private void registerBowRecipes() {
        registerPhoenixBowRecipe();
    }

    private void registerSwordRecipes() {
        registerPhoenixSwordRecipe();
    }

    private void registerPhoenixBowRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_bow");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixBow.createBow());

        recipe.shape(
                " FP",
                "F P",
                " FI"
        );

        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('P', new RecipeChoice.ExactChoice(PhoenixMaterials.createPhoenixFeather()));
        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));

        getServer().addRecipe(recipe);
        getLogger().info("凤凰之弓合成配方已注册！");
    }

    private void registerPhoenixSwordRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_sword");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixSword.createSword());

        recipe.shape(
                "  F",
                " F ",
                "I  "
        );

        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));

        getServer().addRecipe(recipe);
        getLogger().info("凤凰之剑合成配方已注册！");
    }

    private void registerElementalBowRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_bow");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalBow.createBow());

        recipe.shape(
                " EP",
                "E P",
                " EI"
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('P', Material.PHANTOM_MEMBRANE);
        recipe.setIngredient('I', Material.STICK);

        getServer().addRecipe(recipe);
        getLogger().info("元素之弓合成配方已注册！");
    }

    private void registerElementalSwordRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_sword");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalSword.createSword());

        recipe.shape(
                "  E",
                " E ",
                "S  "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('S', Material.STICK);

        getServer().addRecipe(recipe);
        getLogger().info("元素之剑合成配方已注册！");
    }

    private void registerWorkbenchRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_workbench");
        ShapedRecipe recipe = new ShapedRecipe(key, WPWorkbench.createWorkbench());

        recipe.shape(
                "IFI",
                "FCF",
                "IFI"
        );

        recipe.setIngredient('I', Material.IRON_BLOCK);
        recipe.setIngredient('F', Material.BLAZE_POWDER);
        recipe.setIngredient('C', Material.CRAFTING_TABLE);

        getServer().addRecipe(recipe);
        getLogger().info("凤凰铸造台合成配方已注册！");
    }

    private void registerFurnaceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "wp_furnace");
        ShapedRecipe recipe = new ShapedRecipe(key, WPFurnace.createFurnace());

        recipe.shape(
                "IFI",
                "FCF",
                "IFI"
        );

        recipe.setIngredient('I', Material.IRON_BLOCK);
        recipe.setIngredient('F', Material.BLAZE_ROD);
        recipe.setIngredient('C', Material.FURNACE);

        getServer().addRecipe(recipe);
        getLogger().info("WP熔铸炉合成配方已注册！");
    }

    private void registerFurnaceRecipes() {
        registerBlazeRodRecipe();
        registerPrismarineCrystalsRecipe();
        registerGhastTearRecipe();
        registerPhoenixEssenceFurnaceRecipe();
        registerInfernoIngotFurnaceRecipe();
    }

    private void registerBlazeRodRecipe() {
        NamespacedKey key = new NamespacedKey(this, "blaze_rod_from_furnace");
        org.bukkit.inventory.FurnaceRecipe recipe = new org.bukkit.inventory.FurnaceRecipe(
                key,
                new org.bukkit.inventory.ItemStack(Material.BLAZE_ROD),
                Material.BLAZE_POWDER,
                0,
                200
        );

        getServer().addRecipe(recipe);
        getLogger().info("烈焰棒烧制配方已注册！");
    }

    private void registerPrismarineCrystalsRecipe() {
        NamespacedKey key = new NamespacedKey(this, "prismarine_crystals_from_furnace");
        org.bukkit.inventory.FurnaceRecipe recipe = new org.bukkit.inventory.FurnaceRecipe(
                key,
                PhoenixMaterials.createFireCrystal(),
                Material.PRISMARINE_CRYSTALS,
                0,
                200
        );

        getServer().addRecipe(recipe);
        getLogger().info("烈焰水晶烧制配方已注册！");
    }

    private void registerGhastTearRecipe() {
        NamespacedKey key = new NamespacedKey(this, "ghast_tear_from_furnace");
        org.bukkit.inventory.FurnaceRecipe recipe = new org.bukkit.inventory.FurnaceRecipe(
                key,
                new org.bukkit.inventory.ItemStack(Material.BLAZE_POWDER, 2),
                Material.GHAST_TEAR,
                0,
                200
        );

        getServer().addRecipe(recipe);
        getLogger().info("烈焰粉烧制配方已注册！");
    }

    private void registerPhoenixEssenceFurnaceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_essence_from_furnace");
        org.bukkit.inventory.FurnaceRecipe recipe = new org.bukkit.inventory.FurnaceRecipe(
                key,
                PhoenixMaterials.createEssence(),
                Material.NETHER_STAR,
                0,
                300
        );

        getServer().addRecipe(recipe);
        getLogger().info("凤凰精华烧制配方已注册！");
    }

    private void registerInfernoIngotFurnaceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "inferno_ingot_from_furnace");
        org.bukkit.inventory.FurnaceRecipe recipe = new org.bukkit.inventory.FurnaceRecipe(
                key,
                PhoenixMaterials.createInfernoIngot(),
                Material.GOLD_INGOT,
                0,
                300
        );

        getServer().addRecipe(recipe);
        getLogger().info("熔岩锭烧制配方已注册！");
    }

    private void registerElementalEssenceFurnaceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_essence_from_furnace");
        org.bukkit.inventory.FurnaceRecipe recipe = new org.bukkit.inventory.FurnaceRecipe(
                key,
                ElementalMaterials.createElementalEssence(),
                Material.AMETHYST_SHARD,
                0,
                300
        );

        getServer().addRecipe(recipe);
        getLogger().info("元素精华烧制配方已注册！");
    }

    private void registerMaterialRecipes() {
        registerPhoenixFeatherRecipe();
    }

    private void registerEssenceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_essence");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixMaterials.createEssence());

        recipe.shape(
                " B ",
                "BFB",
                " B "
        );

        recipe.setIngredient('B', Material.BLAZE_POWDER);
        recipe.setIngredient('F', Material.NETHER_STAR);

        getServer().addRecipe(recipe);
    }

    private void registerFireCrystalRecipe() {
        NamespacedKey key = new NamespacedKey(this, "fire_crystal");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixMaterials.createFireCrystal());

        recipe.shape(
                " E ",
                "EFE",
                " E "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(PhoenixMaterials.createEssence()));
        recipe.setIngredient('F', Material.BLAZE_ROD);

        getServer().addRecipe(recipe);
    }

    private void registerInfernoIngotRecipe() {
        NamespacedKey key = new NamespacedKey(this, "inferno_ingot");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixMaterials.createInfernoIngot());

        recipe.shape(
                "FFF",
                "FLF",
                "FFF"
        );

        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createEssence()));
        recipe.setIngredient('L', Material.LAVA_BUCKET);

        getServer().addRecipe(recipe);
    }

    private void registerPhoenixFeatherRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_feather");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixMaterials.createPhoenixFeather());

        recipe.shape(
                " E ",
                "EFE",
                " E "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(PhoenixMaterials.createEssence()));
        recipe.setIngredient('F', Material.FEATHER);

        getServer().addRecipe(recipe);
    }

    private void registerStaffRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_staff");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixStaff.createStaff());

        recipe.shape(
                " P ",
                " F ",
                " I "
        );

        recipe.setIngredient('P', new RecipeChoice.ExactChoice(PhoenixMaterials.createPhoenixFeather()));
        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));

        getServer().addRecipe(recipe);
        getLogger().info("凤凰法杖合成配方已注册！");
    }

    private void registerArmorRecipes() {
        registerHelmetRecipe();
        registerChestplateRecipe();
        registerLeggingsRecipe();
        registerBootsRecipe();
    }

    private void registerHelmetRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_helmet");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixArmor.createHelmet());

        recipe.shape(
                "IFI",
                "FCF",
                "   "
        );

        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));
        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('C', Material.GOLDEN_HELMET);

        getServer().addRecipe(recipe);
    }

    private void registerChestplateRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_chestplate");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixArmor.createChestplate());

        recipe.shape(
                "FCF",
                "IFI",
                "IFI"
        );

        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));
        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('C', Material.GOLDEN_CHESTPLATE);

        getServer().addRecipe(recipe);
    }

    private void registerLeggingsRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_leggings");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixArmor.createLeggings());

        recipe.shape(
                "FCF",
                "I I",
                "I I"
        );

        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));
        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('C', Material.GOLDEN_LEGGINGS);

        getServer().addRecipe(recipe);
    }

    private void registerBootsRecipe() {
        NamespacedKey key = new NamespacedKey(this, "phoenix_boots");
        ShapedRecipe recipe = new ShapedRecipe(key, PhoenixArmor.createBoots());

        recipe.shape(
                "I I",
                "FCF",
                "   "
        );

        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));
        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('C', Material.GOLDEN_BOOTS);

        getServer().addRecipe(recipe);
    }

    private void registerElementalMaterialRecipes() {
        registerElementalEssenceRecipe();
        registerWaterEssenceRecipe();
        registerEarthEssenceRecipe();
        registerFireEssenceRecipe();
        registerAirEssenceRecipe();
        registerElementalCoreRecipe();
    }

    private void registerElementalEssenceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_essence");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalMaterials.createElementalEssence());

        recipe.shape(
                "WC ",
                "FA ",
                "   "
        );

        recipe.setIngredient('W', Material.PRISMARINE_CRYSTALS);
        recipe.setIngredient('C', Material.PRISMARINE_SHARD);
        recipe.setIngredient('F', Material.BLAZE_POWDER);
        recipe.setIngredient('A', Material.GHAST_TEAR);

        getServer().addRecipe(recipe);
        getLogger().info("元素精华合成配方已注册！");
    }

    private void registerWaterEssenceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "water_essence");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalMaterials.createWaterEssence());

        recipe.shape(
                "PPP",
                "PWP",
                "PPP"
        );

        recipe.setIngredient('P', Material.PRISMARINE_CRYSTALS);
        recipe.setIngredient('W', Material.WATER_BUCKET);

        getServer().addRecipe(recipe);
    }

    private void registerEarthEssenceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "earth_essence");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalMaterials.createEarthEssence());

        recipe.shape(
                "DDD",
                "DED",
                "DDD"
        );

        recipe.setIngredient('D', Material.DIRT);
        recipe.setIngredient('E', Material.EMERALD);

        getServer().addRecipe(recipe);
    }

    private void registerFireEssenceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "fire_essence");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalMaterials.createFireEssence());

        recipe.shape(
                "LLL",
                "LFL",
                "LLL"
        );

        recipe.setIngredient('L', Material.LAVA_BUCKET);
        recipe.setIngredient('F', Material.BLAZE_ROD);

        getServer().addRecipe(recipe);
    }

    private void registerAirEssenceRecipe() {
        NamespacedKey key = new NamespacedKey(this, "air_essence");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalMaterials.createAirEssence());

        recipe.shape(
                "PPP",
                "PFP",
                "PPP"
        );

        recipe.setIngredient('P', Material.PHANTOM_MEMBRANE);
        recipe.setIngredient('F', Material.FEATHER);

        getServer().addRecipe(recipe);
    }

    private void registerElementalCoreRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_core");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalMaterials.createElementalCore());

        recipe.shape(
                "WE ",
                "EA ",
                "   "
        );

        recipe.setIngredient('W', new RecipeChoice.ExactChoice(ElementalMaterials.createWaterEssence()));
        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createEarthEssence()));
        recipe.setIngredient('A', new RecipeChoice.ExactChoice(ElementalMaterials.createAirEssence()));

        getServer().addRecipe(recipe);
        getLogger().info("元素核心合成配方已注册！");
    }

    private void registerElementalArmorRecipes() {
        registerElementalHelmetRecipe();
        registerElementalChestplateRecipe();
        registerElementalLeggingsRecipe();
        registerElementalBootsRecipe();
    }

    private void registerElementalHelmetRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_helmet");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalArmor.createHelmet());

        recipe.shape(
                "EEE",
                "ECE",
                "   "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('C', Material.DIAMOND_HELMET);

        getServer().addRecipe(recipe);
        getLogger().info("元素头盔合成配方已注册！");
    }

    private void registerElementalChestplateRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_chestplate");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalArmor.createChestplate());

        recipe.shape(
                "ECE",
                "EEE",
                "EEE"
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('C', Material.DIAMOND_CHESTPLATE);

        getServer().addRecipe(recipe);
        getLogger().info("元素胸甲合成配方已注册！");
    }

    private void registerElementalLeggingsRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_leggings");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalArmor.createLeggings());

        recipe.shape(
                "ECE",
                "E E",
                "E E"
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('C', Material.DIAMOND_LEGGINGS);

        getServer().addRecipe(recipe);
        getLogger().info("元素护腿合成配方已注册！");
    }

    private void registerElementalBootsRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_boots");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalArmor.createBoots());

        recipe.shape(
                "E E",
                "ECE",
                "   "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('C', Material.DIAMOND_BOOTS);

        getServer().addRecipe(recipe);
        getLogger().info("元素战靴合成配方已注册！");
    }

    private void registerElementalStaffRecipe() {
        NamespacedKey key = new NamespacedKey(this, "elemental_staff");
        ShapedRecipe recipe = new ShapedRecipe(key, ElementalStaff.createStaff());

        recipe.shape(
                "  E",
                " C ",
                "S  "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('C', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalCore()));
        recipe.setIngredient('S', Material.STICK);

        getServer().addRecipe(recipe);
        getLogger().info("元素法杖合成配方已注册！");
    }

    private void registerGuideRecipe() {
        NamespacedKey key = new NamespacedKey(this, "guide_book");
        ShapedRecipe recipe = new ShapedRecipe(key, GuideBook.createGuideBook());

        recipe.shape(
                " P ",
                "PBP",
                " P "
        );

        recipe.setIngredient('P', Material.PAPER);
        recipe.setIngredient('B', Material.BOOK);

        getServer().addRecipe(recipe);
        getLogger().info("指南书合成配方已注册！");
    }

    private void registerBackpackRecipes() {
        registerSmallBackpackRecipe();
        registerMediumBackpackRecipe();
        registerLargeBackpackRecipe();
    }

    private void registerSmallBackpackRecipe() {
        NamespacedKey key = new NamespacedKey(this, "small_backpack");
        ShapedRecipe recipe = new ShapedRecipe(key, Backpack.createSmallBackpack());

        recipe.shape(
                "LLL",
                "LCL",
                "LLL"
        );

        recipe.setIngredient('L', Material.LEATHER);
        recipe.setIngredient('C', Material.CHEST);

        getServer().addRecipe(recipe);
        getLogger().info("初级背包合成配方已注册！");
    }

    private void registerMediumBackpackRecipe() {
        NamespacedKey key = new NamespacedKey(this, "medium_backpack");
        ShapedRecipe recipe = new ShapedRecipe(key, Backpack.createMediumBackpack());

        recipe.shape(
                "LLL",
                "LCL",
                "LLL"
        );

        recipe.setIngredient('L', Material.LEATHER);
        recipe.setIngredient('C', Material.TRAPPED_CHEST);

        getServer().addRecipe(recipe);
        getLogger().info("中级背包合成配方已注册！");
    }

    private void registerLargeBackpackRecipe() {
        NamespacedKey key = new NamespacedKey(this, "large_backpack");
        ShapedRecipe recipe = new ShapedRecipe(key, Backpack.createLargeBackpack());

        recipe.shape(
                "LLL",
                "LCL",
                "LLL"
        );

        recipe.setIngredient('L', Material.LEATHER);
        recipe.setIngredient('C', Material.SHULKER_BOX);

        getServer().addRecipe(recipe);
        getLogger().info("高级背包合成配方已注册！");
    }

    private void registerTrashCanRecipe() {
        NamespacedKey key = new NamespacedKey(this, "trash_can");
        ShapedRecipe recipe = new ShapedRecipe(key, TrashCan.createTrashCan());

        recipe.shape(
                "OOO",
                "OBO",
                "OOO"
        );

        recipe.setIngredient('O', Material.OBSIDIAN);
        recipe.setIngredient('B', Material.BARREL);

        getServer().addRecipe(recipe);
        getLogger().info("垃圾桶合成配方已注册！");
    }

    private void registerChainPickaxeRecipe() {
        NamespacedKey key = new NamespacedKey(this, "chain_pickaxe");
        ShapedRecipe recipe = new ShapedRecipe(key, ChainPickaxe.createPickaxe());

        recipe.shape(
                "IFI",
                " S ",
                " S "
        );

        recipe.setIngredient('I', new RecipeChoice.ExactChoice(PhoenixMaterials.createInfernoIngot()));
        recipe.setIngredient('F', new RecipeChoice.ExactChoice(PhoenixMaterials.createFireCrystal()));
        recipe.setIngredient('S', Material.STICK);

        getServer().addRecipe(recipe);
        getLogger().info("连锁采集稿合成配方已注册！");
    }

    private void registerRepairMachineRecipe() {
        NamespacedKey key = new NamespacedKey(this, "wp_repair_machine");
        ShapedRecipe recipe = new ShapedRecipe(key, WPRepairMachine.createRepairMachine());

        recipe.shape(
                "III",
                "IAI",
                "III"
        );

        recipe.setIngredient('I', Material.IRON_BLOCK);
        recipe.setIngredient('A', Material.ANVIL);

        getServer().addRecipe(recipe);
        getLogger().info("WP修复机合成配方已注册！");
    }

    private void registerRepairAgentRecipe() {
        NamespacedKey key = new NamespacedKey(this, "repair_agent");
        ShapedRecipe recipe = new ShapedRecipe(key, RepairAgent.createRepairAgent());

        recipe.shape(
                " E ",
                "EDE",
                " E "
        );

        recipe.setIngredient('E', new RecipeChoice.ExactChoice(ElementalMaterials.createElementalEssence()));
        recipe.setIngredient('D', Material.DIAMOND);

        getServer().addRecipe(recipe);
        getLogger().info("万能修补剂合成配方已注册！");
    }

    private void registerGlueRecipes() {
        registerPoorGlueRecipe();
        registerCheapGlueRecipe();
        registerBrandGlueRecipe();
    }

    private void registerPoorGlueRecipe() {
        NamespacedKey key = new NamespacedKey(this, "poor_glue");
        ShapedRecipe recipe = new ShapedRecipe(key, PoorGlue.createGlue());

        recipe.shape(
                "S",
                "C",
                "S"
        );

        recipe.setIngredient('S', Material.STRING);
        recipe.setIngredient('C', Material.CLAY_BALL);

        getServer().addRecipe(recipe);
        getLogger().info("劣质胶水合成配方已注册！");
    }

    private void registerCheapGlueRecipe() {
        NamespacedKey key = new NamespacedKey(this, "cheap_glue");
        ShapedRecipe recipe = new ShapedRecipe(key, CheapGlue.createGlue());

        recipe.shape(
                "S",
                "C",
                "S"
        );

        recipe.setIngredient('S', Material.STRING);
        recipe.setIngredient('C', Material.SLIME_BALL);

        getServer().addRecipe(recipe);
        getLogger().info("廉价胶水合成配方已注册！");
    }

    private void registerBrandGlueRecipe() {
        NamespacedKey key = new NamespacedKey(this, "brand_glue");
        ShapedRecipe recipe = new ShapedRecipe(key, BrandGlue.createGlue());

        recipe.shape(
                "S",
                "C",
                "S"
        );

        recipe.setIngredient('S', Material.STRING);
        recipe.setIngredient('C', Material.HONEYCOMB);

        getServer().addRecipe(recipe);
        getLogger().info("品牌胶水合成配方已注册！");
    }
}
