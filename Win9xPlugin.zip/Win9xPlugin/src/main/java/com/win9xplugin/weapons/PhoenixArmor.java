package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.ArrayList;
import java.util.List;

public class PhoenixArmor {

    public static final String ARMOR_ID = "phoenix_armor";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createHelmet() {
        ItemStack helmet = new ItemStack(Material.GOLDEN_HELMET);
        ItemMeta meta = helmet.getItemMeta();
        if (meta == null) return helmet;

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰战盔");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "凤凰之焰铸就的战盔");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【护甲值】: 2");
        lore.add(ChatColor.GREEN + "【每秒回血】: +0.5 ❤");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.PROTECTION, 4, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 4, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        AttributeModifier armor = new AttributeModifier(
                NamespacedKey.minecraft("generic.armor"),
                2.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.HEAD
        );
        meta.addAttributeModifier(Attribute.GENERIC_ARMOR, armor);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ARMOR_ID + "_helmet");
        }

        helmet.setItemMeta(meta);
        return helmet;
    }

    public static ItemStack createChestplate() {
        ItemStack chestplate = new ItemStack(Material.GOLDEN_CHESTPLATE);
        ItemMeta meta = chestplate.getItemMeta();
        if (meta == null) return chestplate;

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰铠甲");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "凤凰之焰铸就的胸甲");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【护甲值】: 6");
        lore.add(ChatColor.GREEN + "【每秒回血】: +0.5 ❤");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.PROTECTION, 4, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 4, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        AttributeModifier armor = new AttributeModifier(
                NamespacedKey.minecraft("generic.armor"),
                6.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.CHEST
        );
        meta.addAttributeModifier(Attribute.GENERIC_ARMOR, armor);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ARMOR_ID + "_chestplate");
        }

        chestplate.setItemMeta(meta);
        return chestplate;
    }

    public static ItemStack createLeggings() {
        ItemStack leggings = new ItemStack(Material.GOLDEN_LEGGINGS);
        ItemMeta meta = leggings.getItemMeta();
        if (meta == null) return leggings;

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰护腿");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "凤凰之焰铸就的护腿");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【护甲值】: 5");
        lore.add(ChatColor.GREEN + "【每秒回血】: +0.5 ❤");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.PROTECTION, 4, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 4, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        AttributeModifier armor = new AttributeModifier(
                NamespacedKey.minecraft("generic.armor"),
                5.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.LEGS
        );
        meta.addAttributeModifier(Attribute.GENERIC_ARMOR, armor);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ARMOR_ID + "_leggings");
        }

        leggings.setItemMeta(meta);
        return leggings;
    }

    public static ItemStack createBoots() {
        ItemStack boots = new ItemStack(Material.GOLDEN_BOOTS);
        ItemMeta meta = boots.getItemMeta();
        if (meta == null) return boots;

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰战靴");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "凤凰之焰铸就的战靴");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【护甲值】: 2");
        lore.add(ChatColor.GREEN + "【每秒回血】: +0.5 ❤");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.PROTECTION, 4, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 4, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        AttributeModifier armor = new AttributeModifier(
                NamespacedKey.minecraft("generic.armor"),
                2.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.FEET
        );
        meta.addAttributeModifier(Attribute.GENERIC_ARMOR, armor);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ARMOR_ID + "_boots");
        }

        boots.setItemMeta(meta);
        return boots;
    }

    public static boolean isPhoenixArmor(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        String value = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        return value != null && value.startsWith(ARMOR_ID);
    }

    public static int countEquippedPhoenixArmor(org.bukkit.entity.Player player) {
        int count = 0;
        if (isPhoenixArmor(player.getInventory().getHelmet())) count++;
        if (isPhoenixArmor(player.getInventory().getChestplate())) count++;
        if (isPhoenixArmor(player.getInventory().getLeggings())) count++;
        if (isPhoenixArmor(player.getInventory().getBoots())) count++;
        return count;
    }
}
