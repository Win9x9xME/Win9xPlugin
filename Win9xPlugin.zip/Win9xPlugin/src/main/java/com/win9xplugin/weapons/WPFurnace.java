package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class WPFurnace {

    public static final String WP_FURNACE_ID = "wp_furnace";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createFurnace() {
        ItemStack furnace = new ItemStack(Material.FURNACE);
        ItemMeta meta = furnace.getItemMeta();

        if (meta == null) {
            return furnace;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "WP熔铸炉");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "专属WP材料熔铸炉");
        lore.add("");
        lore.add(ChatColor.YELLOW + "使用原版材料在此熔铸炉");
        lore.add(ChatColor.YELLOW + "烧制传说中的WP材料");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, WP_FURNACE_ID);
        }

        furnace.setItemMeta(meta);
        return furnace;
    }

    public static boolean isWPFurnace(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && WP_FURNACE_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}