package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.ArrayList;
import java.util.List;

public class GuideBook {

    public static final String BOOK_ID = "win9x_guide_book";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createGuideBook() {
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();

        if (meta == null) {
            return book;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "Win9xPlugin 指南 " + ChatColor.YELLOW + "(右键打开)");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "右键打开查看所有物品的合成配方");
        lore.add("");
        lore.add(ChatColor.LIGHT_PURPLE + "【包含内容】");
        lore.add(ChatColor.YELLOW + "  • 凤凰法杖");
        lore.add(ChatColor.YELLOW + "  • 凤凰战盔");
        lore.add(ChatColor.YELLOW + "  • 凤凰铠甲");
        lore.add(ChatColor.YELLOW + "  • 凤凰护腿");
        lore.add(ChatColor.YELLOW + "  • 凤凰战靴");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GREEN + "普通");

        meta.setLore(lore);

        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, BOOK_ID);
        }

        book.setItemMeta(meta);
        return book;
    }

    public static boolean isGuideBook(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && BOOK_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}
