package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ChainPickaxe {

    public static final String CHAIN_PICKAXE_ID = "chain_pickaxe";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createPickaxe() {
        ItemStack pickaxe = new ItemStack(Material.DIAMOND_PICKAXE);
        ItemMeta meta = pickaxe.getItemMeta();

        if (meta == null) {
            return pickaxe;
        }

        meta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "连锁采集稿");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "自动连锁采集周围的同类矿物");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【效率】: +5 挖掘速度");
        lore.add(ChatColor.GREEN + "【特效】: 连锁采集范围 3x3x3");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.AQUA + "稀有");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.EFFICIENCY, 5, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, CHAIN_PICKAXE_ID);
        }

        pickaxe.setItemMeta(meta);
        return pickaxe;
    }

    public static boolean isChainPickaxe(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && CHAIN_PICKAXE_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}