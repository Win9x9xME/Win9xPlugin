package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ElementalArmor {

    public static final String ELEMENTAL_ARMOR_ID = "elemental_armor";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createHelmet() {
        ItemStack helmet = new ItemStack(Material.DIAMOND_HELMET);
        ItemMeta meta = helmet.getItemMeta();

        if (meta == null) {
            return helmet;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素头盔");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的头盔");
        lore.add("");
        lore.add(ChatColor.AQUA + "效果:");
        lore.add(ChatColor.GRAY + "  水下呼吸 I");
        lore.add(ChatColor.GRAY + "  抗火 I");
        lore.add(ChatColor.GRAY + "  抗性提升 I");
        lore.add(ChatColor.GRAY + "  生命恢复 I");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.AQUA_AFFINITY, 1, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 1, true);
        meta.addEnchant(Enchantment.PROTECTION, 1, true);
        meta.addEnchant(Enchantment.RESPIRATION, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "elemental_helmet");
        }

        helmet.setItemMeta(meta);
        return helmet;
    }

    public static ItemStack createChestplate() {
        ItemStack chestplate = new ItemStack(Material.DIAMOND_CHESTPLATE);
        ItemMeta meta = chestplate.getItemMeta();

        if (meta == null) {
            return chestplate;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素胸甲");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的胸甲");
        lore.add("");
        lore.add(ChatColor.AQUA + "效果:");
        lore.add(ChatColor.GRAY + "  水下呼吸 I");
        lore.add(ChatColor.GRAY + "  抗火 I");
        lore.add(ChatColor.GRAY + "  抗性提升 I");
        lore.add(ChatColor.GRAY + "  生命恢复 I");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.AQUA_AFFINITY, 1, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 1, true);
        meta.addEnchant(Enchantment.PROTECTION, 1, true);
        meta.addEnchant(Enchantment.RESPIRATION, 1, true);
        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "elemental_chestplate");
        }

        chestplate.setItemMeta(meta);
        return chestplate;
    }

    public static ItemStack createLeggings() {
        ItemStack leggings = new ItemStack(Material.DIAMOND_LEGGINGS);
        ItemMeta meta = leggings.getItemMeta();

        if (meta == null) {
            return leggings;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素护腿");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的护腿");
        lore.add("");
        lore.add(ChatColor.AQUA + "效果:");
        lore.add(ChatColor.GRAY + "  水下呼吸 I");
        lore.add(ChatColor.GRAY + "  抗火 I");
        lore.add(ChatColor.GRAY + "  抗性提升 I");
        lore.add(ChatColor.GRAY + "  生命恢复 I");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.AQUA_AFFINITY, 1, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 1, true);
        meta.addEnchant(Enchantment.PROTECTION, 1, true);
        meta.addEnchant(Enchantment.RESPIRATION, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "elemental_leggings");
        }

        leggings.setItemMeta(meta);
        return leggings;
    }

    public static ItemStack createBoots() {
        ItemStack boots = new ItemStack(Material.DIAMOND_BOOTS);
        ItemMeta meta = boots.getItemMeta();

        if (meta == null) {
            return boots;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素战靴");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的靴子");
        lore.add("");
        lore.add(ChatColor.AQUA + "效果:");
        lore.add(ChatColor.GRAY + "  水下呼吸 I");
        lore.add(ChatColor.GRAY + "  抗火 I");
        lore.add(ChatColor.GRAY + "  抗性提升 I");
        lore.add(ChatColor.GRAY + "  生命恢复 I");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.AQUA_AFFINITY, 1, true);
        meta.addEnchant(Enchantment.FIRE_PROTECTION, 1, true);
        meta.addEnchant(Enchantment.PROTECTION, 1, true);
        meta.addEnchant(Enchantment.RESPIRATION, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "elemental_boots");
        }

        boots.setItemMeta(meta);
        return boots;
    }

    public static boolean isElementalArmor(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && meta.getPersistentDataContainer().get(key, PersistentDataType.STRING).toString().startsWith("elemental_");
    }
}