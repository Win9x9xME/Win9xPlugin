package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.ArrayList;
import java.util.List;

public class PhoenixStaff {

    public static final String WEAPON_ID = "phoenix_staff";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createStaff() {
        ItemStack staff = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = staff.getItemMeta();

        if (meta == null) {
            return staff;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰法杖");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "传说中的凤凰之杖，蕴含");
        lore.add(ChatColor.GRAY + "着不死鸟的烈焰之力。");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【武器属性】");
        lore.add(ChatColor.RED + "  攻击力: +12");
        lore.add(ChatColor.RED + "  攻击速度: +0.6");
        lore.add("");
        lore.add(ChatColor.LIGHT_PURPLE + "【特殊效果】");
        lore.add(ChatColor.GREEN + "  生命偷取: 30% 伤害转化为生命");
        lore.add(ChatColor.YELLOW + "  烈焰暴击: 25% 几率造成双倍伤害并点燃");
        lore.add(ChatColor.RED + "  凤凰冲击: 右键蓄力释放火焰冲击波");
        lore.add(ChatColor.GRAY + "    - 蓄力3秒达到最大效果 (伤害10→30)");
        lore.add(ChatColor.GRAY + "    - 冷却时间: 20秒");
        lore.add(ChatColor.DARK_PURPLE + "  范围伤害: 攻击对周围敌人造成溅射");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");

        meta.setLore(lore);

        meta.addEnchant(Enchantment.FIRE_ASPECT, 2, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);

        meta.setUnbreakable(true);

        AttributeModifier attackDamage = new AttributeModifier(
                NamespacedKey.minecraft("generic.attack_damage"),
                12.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.HAND
        );
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, attackDamage);

        AttributeModifier attackSpeed = new AttributeModifier(
                NamespacedKey.minecraft("generic.attack_speed"),
                0.6,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.HAND
        );
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_SPEED, attackSpeed);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, WEAPON_ID);
        }

        staff.setItemMeta(meta);
        return staff;
    }

    public static boolean isPhoenixStaff(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && WEAPON_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}
