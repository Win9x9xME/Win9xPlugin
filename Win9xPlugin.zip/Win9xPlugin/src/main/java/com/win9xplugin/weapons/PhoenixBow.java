package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class PhoenixBow {

    public static final String PHOENIX_BOW_ID = "phoenix_bow";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createBow() {
        ItemStack bow = new ItemStack(Material.BOW);
        ItemMeta meta = bow.getItemMeta();

        if (meta == null) {
            return bow;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰之弓");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "凤凰之焰铸就的神弓");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【攻击力】: +8");
        lore.add(ChatColor.AQUA + "【特效】: 射出的箭矢会点燃目标");
        lore.add(ChatColor.GREEN + "【无限箭矢】: 无需消耗箭矢");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.POWER, 4, true);
        meta.addEnchant(Enchantment.FLAME, 1, true);
        meta.addEnchant(Enchantment.INFINITY, 1, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, PHOENIX_BOW_ID);
        }

        bow.setItemMeta(meta);
        return bow;
    }

    public static boolean isPhoenixBow(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && PHOENIX_BOW_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}