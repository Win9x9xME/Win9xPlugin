package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ElementalMaterials {

    public static final String ELEMENTAL_MATERIAL_ID = "elemental_material";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createElementalEssence() {
        return createMaterial(Material.AMETHYST_SHARD, "元素精华", "蕴含四种元素力量的结晶", 1);
    }

    public static ItemStack createWaterEssence() {
        return createMaterial(Material.PRISMARINE_CRYSTALS, "水元素精华", "纯净的水元素能量", 1);
    }

    public static ItemStack createEarthEssence() {
        return createMaterial(Material.ROOTED_DIRT, "土元素精华", "厚重的大地能量", 1);
    }

    public static ItemStack createFireEssence() {
        return createMaterial(Material.BLAZE_POWDER, "火元素精华", "炽热的火焰能量", 1);
    }

    public static ItemStack createAirEssence() {
        return createMaterial(Material.GHAST_TEAR, "气元素精华", "轻盈的风之能量", 1);
    }

    public static ItemStack createElementalCore() {
        return createMaterial(Material.NETHER_STAR, "元素核心", "四元素融合的核心", 1);
    }

    private static ItemStack createMaterial(Material base, String name, String desc, int amount) {
        ItemStack item = new ItemStack(base, amount);
        ItemMeta meta = item.getItemMeta();

        if (meta == null) {
            return item;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + name);

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + desc);
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, name);
        }

        item.setItemMeta(meta);
        return item;
    }

    public static boolean isElementalMaterial(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING);
    }

    public static ItemStack getMaterialByName(String name) {
        return switch (name) {
            case "元素精华" -> createElementalEssence();
            case "水元素精华" -> createWaterEssence();
            case "土元素精华" -> createEarthEssence();
            case "火元素精华" -> createFireEssence();
            case "气元素精华" -> createAirEssence();
            case "元素核心" -> createElementalCore();
            default -> null;
        };
    }
}