package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class BrandGlue {

    public static final String BRAND_GLUE_ID = "brand_glue";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createGlue() {
        ItemStack glue = new ItemStack(Material.SLIME_BALL);
        ItemMeta meta = glue.getItemMeta();

        if (meta == null) {
            return glue;
        }

        meta.setDisplayName(ChatColor.BLUE + "" + ChatColor.BOLD + "品牌胶水");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "品质保证的品牌胶水");
        lore.add("");
        lore.add(ChatColor.YELLOW + "在WP修复机中使用");
        lore.add(ChatColor.GREEN + "稳定回复 15 点耐久");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.BLUE + "稀有");
        meta.setLore(lore);

        if (key != null) {
            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(key, PersistentDataType.STRING, BRAND_GLUE_ID);
        }

        glue.setItemMeta(meta);
        return glue;
    }

    public static boolean isBrandGlue(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(key, PersistentDataType.STRING)) {
            return false;
        }
        String value = container.get(key, PersistentDataType.STRING);
        return BRAND_GLUE_ID.equals(value);
    }

    public static int getRepairAmount() {
        return 15;
    }
}
