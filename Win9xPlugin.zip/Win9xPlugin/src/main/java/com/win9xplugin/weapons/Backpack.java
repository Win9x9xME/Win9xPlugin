package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class Backpack {

    public static final String BACKPACK_ID_PREFIX = "wp_backpack_";
    public static final String BACKPACK_SMALL = "small";
    public static final String BACKPACK_MEDIUM = "medium";
    public static final String BACKPACK_LARGE = "large";

    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createSmallBackpack() {
        return createBackpack(BACKPACK_SMALL, "初级背包", 18, ChatColor.GRAY);
    }

    public static ItemStack createMediumBackpack() {
        return createBackpack(BACKPACK_MEDIUM, "中级背包", 36, ChatColor.BLUE);
    }

    public static ItemStack createLargeBackpack() {
        return createBackpack(BACKPACK_LARGE, "高级背包", 54, ChatColor.DARK_PURPLE);
    }

    private static ItemStack createBackpack(String type, String name, int size, ChatColor color) {
        ItemStack backpack = new ItemStack(Material.CHEST);
        ItemMeta meta = backpack.getItemMeta();

        if (meta == null) {
            return backpack;
        }

        meta.setDisplayName(color + "" + ChatColor.BOLD + name);

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "便携式背包");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【容量】: " + (size / 9) + "x9");
        lore.add(ChatColor.AQUA + "【右键】: 打开背包");
        lore.add(ChatColor.GOLD + "【首次使用】: 输入背包名称");
        lore.add("");

        String rarity = switch (type) {
            case BACKPACK_SMALL -> "普通";
            case BACKPACK_MEDIUM -> "优良";
            case BACKPACK_LARGE -> "史诗";
            default -> "普通";
        };
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + color + rarity);
        meta.setLore(lore);

        if (key != null) {
            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(key, PersistentDataType.STRING, BACKPACK_ID_PREFIX + type);
            container.set(new NamespacedKey(key.getNamespace(), "backpack_size"), PersistentDataType.INTEGER, size);
        }

        backpack.setItemMeta(meta);
        return backpack;
    }

    public static boolean isBackpack(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(key, PersistentDataType.STRING)) {
            return false;
        }
        String id = container.get(key, PersistentDataType.STRING);
        return id != null && id.startsWith(BACKPACK_ID_PREFIX);
    }

    public static String getBackpackType(ItemStack item) {
        if (!isBackpack(item)) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        String id = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        return id.substring(BACKPACK_ID_PREFIX.length());
    }

    public static int getBackpackSize(ItemStack item) {
        if (!isBackpack(item)) {
            return 0;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return 0;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        NamespacedKey sizeKey = new NamespacedKey(key.getNamespace(), "backpack_size");
        if (!container.has(sizeKey, PersistentDataType.INTEGER)) {
            return 0;
        }
        return container.get(sizeKey, PersistentDataType.INTEGER);
    }

    public static boolean isNamed(ItemStack item) {
        if (!isBackpack(item)) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        NamespacedKey nameKey = new NamespacedKey(key.getNamespace(), "backpack_name");
        return container.has(nameKey, PersistentDataType.STRING);
    }

    public static String getBackpackName(ItemStack item) {
        if (!isBackpack(item)) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        NamespacedKey nameKey = new NamespacedKey(key.getNamespace(), "backpack_name");
        if (!container.has(nameKey, PersistentDataType.STRING)) {
            return null;
        }
        return container.get(nameKey, PersistentDataType.STRING);
    }

    public static void setBackpackName(ItemStack item, String name) {
        if (!isBackpack(item)) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        NamespacedKey nameKey = new NamespacedKey(key.getNamespace(), "backpack_name");
        container.set(nameKey, PersistentDataType.STRING, name);

        String type = getBackpackType(item);
        String displayName = "";
        if (BACKPACK_SMALL.equals(type)) {
            displayName = ChatColor.GRAY + "" + ChatColor.BOLD + name;
        } else if (BACKPACK_MEDIUM.equals(type)) {
            displayName = ChatColor.BLUE + "" + ChatColor.BOLD + name;
        } else if (BACKPACK_LARGE.equals(type)) {
            displayName = ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + name;
        }
        meta.setDisplayName(displayName);

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "便携式背包");
        lore.add(ChatColor.YELLOW + "【名称】: " + name);
        lore.add(ChatColor.AQUA + "【右键】: 打开背包");
        meta.setLore(lore);

        item.setItemMeta(meta);
    }

    public static String getTypeName(String type) {
        switch (type) {
            case BACKPACK_SMALL:
                return "初级背包";
            case BACKPACK_MEDIUM:
                return "中级背包";
            case BACKPACK_LARGE:
                return "高级背包";
            default:
                return "未知背包";
        }
    }
}