package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class TrashCan {

    public static final String TRASH_CAN_ID = "wp_trash_can";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createTrashCan() {
        ItemStack trashCan = new ItemStack(Material.BARREL);
        ItemMeta meta = trashCan.getItemMeta();

        if (meta == null) {
            return trashCan;
        }

        meta.setDisplayName(ChatColor.DARK_GRAY + "" + ChatColor.BOLD + "便携式垃圾桶");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "将不要的物品丢进去吧");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【容量】: 6x9");
        lore.add(ChatColor.RED + "【右键】: 打开垃圾桶");
        lore.add(ChatColor.GRAY + "关闭后物品将被清除");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GRAY + "普通");
        meta.setLore(lore);

        if (key != null) {
            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(key, PersistentDataType.STRING, TRASH_CAN_ID);
        }

        trashCan.setItemMeta(meta);
        return trashCan;
    }

    public static boolean isTrashCan(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(key, PersistentDataType.STRING)) {
            return false;
        }
        String id = container.get(key, PersistentDataType.STRING);
        return TRASH_CAN_ID.equals(id);
    }
}
