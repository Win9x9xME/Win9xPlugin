package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class WPWorkbench {

    public static final String WORKBENCH_ID = "wp_workbench";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createWorkbench() {
        ItemStack workbench = new ItemStack(Material.CRAFTING_TABLE);
        ItemMeta meta = workbench.getItemMeta();

        if (meta == null) {
            return workbench;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "WP铸造台");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "专属WP装备铸造台");
        lore.add("");
        lore.add(ChatColor.YELLOW + "使用WP材料在此工作台");
        lore.add(ChatColor.YELLOW + "合成传说中的WP装备");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, WORKBENCH_ID);
        }

        workbench.setItemMeta(meta);
        return workbench;
    }

    public static boolean isWPWorkbench(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && WORKBENCH_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}