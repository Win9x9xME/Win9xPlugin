package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ElementalSword {

    public static final String ELEMENTAL_SWORD_ID = "elemental_sword";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createSword() {
        ItemStack sword = new ItemStack(Material.DIAMOND_SWORD);
        ItemMeta meta = sword.getItemMeta();

        if (meta == null) {
            return sword;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素之剑");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的神剑");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【攻击力】: +10");
        lore.add(ChatColor.AQUA + "【特效】: 攻击时随机触发元素效果");
        lore.add(ChatColor.GRAY + "  - 水元素: 击退目标");
        lore.add(ChatColor.GRAY + "  - 土元素: 禁锢目标3秒");
        lore.add(ChatColor.GRAY + "  - 火元素: 点燃目标5秒");
        lore.add(ChatColor.GRAY + "  - 气元素: 提升攻击速度");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.SHARPNESS, 4, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        AttributeModifier damage = new AttributeModifier(
                NamespacedKey.minecraft("generic.attack_damage"),
                10.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.MAINHAND
        );
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, damage);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ELEMENTAL_SWORD_ID);
        }

        sword.setItemMeta(meta);
        return sword;
    }

    public static boolean isElementalSword(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && ELEMENTAL_SWORD_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}