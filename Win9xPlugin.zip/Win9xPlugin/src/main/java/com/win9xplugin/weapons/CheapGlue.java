package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class CheapGlue {

    public static final String CHEAP_GLUE_ID = "cheap_glue";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createGlue() {
        ItemStack glue = new ItemStack(Material.SLIME_BALL);
        ItemMeta meta = glue.getItemMeta();

        if (meta == null) {
            return glue;
        }

        meta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + "廉价胶水");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "价格实惠的修补胶水");
        lore.add("");
        lore.add(ChatColor.YELLOW + "在WP修复机中使用");
        lore.add(ChatColor.GOLD + "随机回复 -15~15 点耐久");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GREEN + "优良");
        meta.setLore(lore);

        if (key != null) {
            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(key, PersistentDataType.STRING, CHEAP_GLUE_ID);
        }

        glue.setItemMeta(meta);
        return glue;
    }

    public static boolean isCheapGlue(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(key, PersistentDataType.STRING)) {
            return false;
        }
        String value = container.get(key, PersistentDataType.STRING);
        return CHEAP_GLUE_ID.equals(value);
    }

    public static int getRepairAmount() {
        return -15 + (int) (Math.random() * 31);
    }
}
