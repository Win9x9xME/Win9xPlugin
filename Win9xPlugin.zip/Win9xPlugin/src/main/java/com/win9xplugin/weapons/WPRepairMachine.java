package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class WPRepairMachine {

    public static final String REPAIR_MACHINE_ID = "wp_repair_machine";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createRepairMachine() {
        ItemStack machine = new ItemStack(Material.ANVIL);
        ItemMeta meta = machine.getItemMeta();

        if (meta == null) {
            return machine;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "WP修复机");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "专属WP装备修复机");
        lore.add("");
        lore.add(ChatColor.YELLOW + "在修复机中放入需要修复的工具");
        lore.add(ChatColor.YELLOW + "和万能修补剂修复装备耐久");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, REPAIR_MACHINE_ID);
        }

        machine.setItemMeta(meta);
        return machine;
    }

    public static boolean isWPRepairMachine(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && REPAIR_MACHINE_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}