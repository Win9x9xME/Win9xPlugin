package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ElementalStaff {

    public static final String ELEMENTAL_STAFF_ID = "elemental_staff";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createStaff() {
        ItemStack staff = new ItemStack(Material.STICK);
        ItemMeta meta = staff.getItemMeta();

        if (meta == null) {
            return staff;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素法杖");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的法杖");
        lore.add("");
        lore.add(ChatColor.AQUA + "右键: " + ChatColor.GRAY + "获得所有正面buff 1级效果持续10秒");
        lore.add(ChatColor.AQUA + "左键: " + ChatColor.GRAY + "攻击伤害 +2");
        lore.add(ChatColor.YELLOW + "冷却时间: 34秒");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ELEMENTAL_STAFF_ID);
        }

        staff.setItemMeta(meta);
        return staff;
    }

    public static boolean isElementalStaff(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && ELEMENTAL_STAFF_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}