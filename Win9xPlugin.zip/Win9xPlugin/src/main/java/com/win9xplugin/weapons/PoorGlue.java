package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class PoorGlue {

    public static final String POOR_GLUE_ID = "poor_glue";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createGlue() {
        ItemStack glue = new ItemStack(Material.SLIME_BALL);
        ItemMeta meta = glue.getItemMeta();

        if (meta == null) {
            return glue;
        }

        meta.setDisplayName(ChatColor.GRAY + "" + ChatColor.BOLD + "劣质胶水");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "劣质的修补胶水");
        lore.add("");
        lore.add(ChatColor.YELLOW + "在WP修复机中使用");
        lore.add(ChatColor.RED + "随机回复 -30~10 点耐久");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GRAY + "普通");
        meta.setLore(lore);

        if (key != null) {
            PersistentDataContainer container = meta.getPersistentDataContainer();
            container.set(key, PersistentDataType.STRING, POOR_GLUE_ID);
        }

        glue.setItemMeta(meta);
        return glue;
    }

    public static boolean isPoorGlue(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(key, PersistentDataType.STRING)) {
            return false;
        }
        String value = container.get(key, PersistentDataType.STRING);
        return POOR_GLUE_ID.equals(value);
    }

    public static int getRepairAmount() {
        return -30 + (int) (Math.random() * 41);
    }
}
