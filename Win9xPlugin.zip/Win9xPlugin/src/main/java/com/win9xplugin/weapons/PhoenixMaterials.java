package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class PhoenixMaterials {

    public static final String MATERIAL_ID = "phoenix_material";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createEssence() {
        return createMaterial(Material.BLAZE_POWDER, "凤凰精华", "蕴含凤凰的火焰精华", 1);
    }

    public static ItemStack createFireCrystal() {
        return createMaterial(Material.EMERALD, "烈焰水晶", "纯净的火焰能量结晶", 1);
    }

    public static ItemStack createPhoenixFeather() {
        return createMaterial(Material.FEATHER, "凤凰羽毛", "传说中凤凰的羽毛", 1);
    }

    public static ItemStack createInfernoIngot() {
        return createMaterial(Material.GOLD_INGOT, "熔岩锭", "熔岩与黄金的完美融合", 1);
    }

    private static ItemStack createMaterial(Material base, String name, String desc, int amount) {
        ItemStack item = new ItemStack(base, amount);
        ItemMeta meta = item.getItemMeta();

        if (meta == null) {
            return item;
        }

        meta.setDisplayName(ChatColor.GOLD + name);

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + desc);
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.YELLOW + "珍贵");
        meta.setLore(lore);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, name);
        }

        item.setItemMeta(meta);
        return item;
    }

    public static boolean isPhoenixMaterial(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING);
    }

    public static ItemStack getMaterialByName(String name) {
        return switch (name) {
            case "凤凰精华" -> createEssence();
            case "烈焰水晶" -> createFireCrystal();
            case "凤凰羽毛" -> createPhoenixFeather();
            case "熔岩锭" -> createInfernoIngot();
            default -> null;
        };
    }
}
