package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class RepairAgent {

    public static final String REPAIR_AGENT_ID = "repair_agent";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createRepairAgent() {
        ItemStack agent = new ItemStack(Material.NETHERITE_SCRAP);
        ItemMeta meta = agent.getItemMeta();

        if (meta == null) {
            return agent;
        }

        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "万能修补剂");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "用于修复各种工具和装备");
        lore.add(ChatColor.GRAY + "在WP修复机中使用");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.LIGHT_PURPLE + "精良");
        meta.setLore(lore);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, REPAIR_AGENT_ID);
        }

        agent.setItemMeta(meta);
        return agent;
    }

    public static boolean isRepairAgent(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && REPAIR_AGENT_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}