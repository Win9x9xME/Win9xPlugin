package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class PhoenixSword {

    public static final String PHOENIX_SWORD_ID = "phoenix_sword";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createSword() {
        ItemStack sword = new ItemStack(Material.GOLDEN_SWORD);
        ItemMeta meta = sword.getItemMeta();

        if (meta == null) {
            return sword;
        }

        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + "凤凰之剑");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "凤凰之焰铸就的神剑");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【攻击力】: +12");
        lore.add(ChatColor.AQUA + "【特效】: 攻击时点燃目标5秒");
        lore.add(ChatColor.GREEN + "【火焰伤害】: +4");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.GOLD + "传说");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.SHARPNESS, 5, true);
        meta.addEnchant(Enchantment.FIRE_ASPECT, 2, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);

        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.setUnbreakable(true);

        AttributeModifier damage = new AttributeModifier(
                NamespacedKey.minecraft("generic.attack_damage"),
                12.0,
                AttributeModifier.Operation.ADD_NUMBER,
                EquipmentSlotGroup.MAINHAND
        );
        meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, damage);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, PHOENIX_SWORD_ID);
        }

        sword.setItemMeta(meta);
        return sword;
    }

    public static boolean isPhoenixSword(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && PHOENIX_SWORD_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}