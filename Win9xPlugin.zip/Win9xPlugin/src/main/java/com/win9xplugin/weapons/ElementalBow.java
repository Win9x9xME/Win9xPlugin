package com.win9xplugin.weapons;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ElementalBow {

    public static final String ELEMENTAL_BOW_ID = "elemental_bow";
    private static NamespacedKey key;

    public static void setKey(NamespacedKey namespacedKey) {
        key = namespacedKey;
    }

    public static ItemStack createBow() {
        ItemStack bow = new ItemStack(Material.BOW);
        ItemMeta meta = bow.getItemMeta();

        if (meta == null) {
            return bow;
        }

        meta.setDisplayName(ChatColor.DARK_PURPLE + "" + ChatColor.BOLD + "元素之弓");

        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "蕴含四种元素力量的神弓");
        lore.add("");
        lore.add(ChatColor.YELLOW + "【攻击力】: +6");
        lore.add(ChatColor.AQUA + "【特效】: 射出的箭矢会随机触发元素效果");
        lore.add(ChatColor.GRAY + "  - 水元素: 击退目标");
        lore.add(ChatColor.GRAY + "  - 土元素: 禁锢目标3秒");
        lore.add(ChatColor.GRAY + "  - 火元素: 点燃目标5秒");
        lore.add(ChatColor.GRAY + "  - 气元素: 加速箭矢飞行");
        lore.add("");
        lore.add(ChatColor.DARK_GRAY + "稀有度: " + ChatColor.DARK_PURPLE + "史诗");
        meta.setLore(lore);

        meta.addEnchant(Enchantment.POWER, 3, true);
        meta.addEnchant(Enchantment.INFINITY, 1, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.addEnchant(Enchantment.BINDING_CURSE, 1, true);

        if (key != null) {
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, ELEMENTAL_BOW_ID);
        }

        bow.setItemMeta(meta);
        return bow;
    }

    public static boolean isElementalBow(ItemStack item) {
        if (item == null || !item.hasItemMeta() || key == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)
                && ELEMENTAL_BOW_ID.equals(meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
    }
}