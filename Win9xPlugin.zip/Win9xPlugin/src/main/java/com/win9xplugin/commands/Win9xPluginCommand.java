package com.win9xplugin.commands;

import com.win9xplugin.Win9xPlugin;
import com.win9xplugin.unlock.UnlockGUI;
import com.win9xplugin.utils.DebugLogger;
import com.win9xplugin.weapons.Backpack;
import com.win9xplugin.weapons.BrandGlue;
import com.win9xplugin.weapons.CheapGlue;
import com.win9xplugin.weapons.ElementalArmor;
import com.win9xplugin.weapons.ElementalBow;
import com.win9xplugin.weapons.ElementalMaterials;
import com.win9xplugin.weapons.ElementalStaff;
import com.win9xplugin.weapons.ElementalSword;
import com.win9xplugin.weapons.GuideBook;
import com.win9xplugin.weapons.PhoenixArmor;
import com.win9xplugin.weapons.PhoenixBow;
import com.win9xplugin.weapons.PhoenixMaterials;
import com.win9xplugin.weapons.PhoenixStaff;
import com.win9xplugin.weapons.PhoenixSword;
import com.win9xplugin.weapons.PoorGlue;
import com.win9xplugin.weapons.RepairAgent;
import com.win9xplugin.weapons.TrashCan;
import com.win9xplugin.weapons.ChainPickaxe;
import com.win9xplugin.weapons.WPFurnace;
import com.win9xplugin.weapons.WPRepairMachine;
import com.win9xplugin.weapons.WPWorkbench;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class Win9xPluginCommand implements CommandExecutor, TabCompleter {

    private final Win9xPlugin plugin;

    public Win9xPluginCommand(Win9xPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String subCommand = args[0].toLowerCase();

        switch (subCommand) {
            case "help":
                sendHelp(sender);
                break;
            case "info":
                sendInfo(sender);
                break;
            case "reload":
                handleReload(sender);
                break;
            case "give":
                handleGive(sender, args);
                break;
            case "guide":
                handleGuide(sender);
                break;
            case "unlock":
            case "research":
                handleUnlock(sender);
                break;
            default:
                sender.sendMessage(ChatColor.RED + "未知的子命令！使用 /win9xplugin help 查看帮助。");
                break;
        }

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "" + ChatColor.STRIKETHROUGH + "===============" +
                ChatColor.GOLD + " Win9xPlugin " +
                ChatColor.GOLD + ChatColor.STRIKETHROUGH + "===============");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.YELLOW + "  /win9xplugin help" + ChatColor.GRAY + " - 显示帮助信息");
        sender.sendMessage(ChatColor.YELLOW + "  /win9xplugin info" + ChatColor.GRAY + " - 显示插件信息");
        sender.sendMessage(ChatColor.YELLOW + "  /win9xplugin reload" + ChatColor.GRAY + " - 重载插件");
        sender.sendMessage(ChatColor.YELLOW + "  /win9xplugin guide" + ChatColor.GRAY + " - 获取指南书");
        sender.sendMessage(ChatColor.YELLOW + "  /win9xplugin unlock" + ChatColor.GRAY + " - 打开研究界面");
        sender.sendMessage(ChatColor.YELLOW + "  /win9xplugin give <物品ID>" + ChatColor.GRAY + " - 获取指定物品");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "可用物品ID:");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_staff" + ChatColor.GRAY + " - 凤凰法杖");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_bow" + ChatColor.GRAY + " - 凤凰之弓");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_sword" + ChatColor.GRAY + " - 凤凰之剑");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_helmet" + ChatColor.GRAY + " - 凤凰战盔");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_chestplate" + ChatColor.GRAY + " - 凤凰铠甲");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_leggings" + ChatColor.GRAY + " - 凤凰护腿");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_boots" + ChatColor.GRAY + " - 凤凰战靴");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_essence" + ChatColor.GRAY + " - 凤凰精华");
        sender.sendMessage(ChatColor.WHITE + "  fire_crystal" + ChatColor.GRAY + " - 烈焰水晶");
        sender.sendMessage(ChatColor.WHITE + "  phoenix_feather" + ChatColor.GRAY + " - 凤凰羽毛");
        sender.sendMessage(ChatColor.WHITE + "  inferno_ingot" + ChatColor.GRAY + " - 熔岩锭");
        sender.sendMessage(ChatColor.WHITE + "  wp_workbench" + ChatColor.GRAY + " - WP铸造台");
        sender.sendMessage(ChatColor.WHITE + "  wp_furnace" + ChatColor.GRAY + " - WP熔铸炉");
        sender.sendMessage(ChatColor.WHITE + "  elemental_staff" + ChatColor.GRAY + " - 元素法杖");
        sender.sendMessage(ChatColor.WHITE + "  elemental_bow" + ChatColor.GRAY + " - 元素之弓");
        sender.sendMessage(ChatColor.WHITE + "  elemental_sword" + ChatColor.GRAY + " - 元素之剑");
        sender.sendMessage(ChatColor.WHITE + "  elemental_helmet" + ChatColor.GRAY + " - 元素头盔");
        sender.sendMessage(ChatColor.WHITE + "  elemental_chestplate" + ChatColor.GRAY + " - 元素胸甲");
        sender.sendMessage(ChatColor.WHITE + "  elemental_leggings" + ChatColor.GRAY + " - 元素护腿");
        sender.sendMessage(ChatColor.WHITE + "  elemental_boots" + ChatColor.GRAY + " - 元素战靴");
        sender.sendMessage(ChatColor.WHITE + "  elemental_essence" + ChatColor.GRAY + " - 元素精华");
        sender.sendMessage(ChatColor.WHITE + "  guide_book" + ChatColor.GRAY + " - 指南书");
        sender.sendMessage(ChatColor.WHITE + "  small_backpack" + ChatColor.GRAY + " - 初级背包");
        sender.sendMessage(ChatColor.WHITE + "  medium_backpack" + ChatColor.GRAY + " - 中级背包");
        sender.sendMessage(ChatColor.WHITE + "  large_backpack" + ChatColor.GRAY + " - 高级背包");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "" + ChatColor.STRIKETHROUGH + "======================================");
    }

    private void sendInfo(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "" + ChatColor.STRIKETHROUGH + "===============" +
                ChatColor.GOLD + " 插件信息 " +
                ChatColor.GOLD + ChatColor.STRIKETHROUGH + "===============");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.YELLOW + "  插件名称: " + ChatColor.WHITE + plugin.getDescription().getName());
        sender.sendMessage(ChatColor.YELLOW + "  版本: " + ChatColor.WHITE + plugin.getDescription().getVersion());
        sender.sendMessage(ChatColor.YELLOW + "  作者: " + ChatColor.WHITE + plugin.getDescription().getAuthors());
        sender.sendMessage(ChatColor.YELLOW + "  描述: " + ChatColor.WHITE + plugin.getDescription().getDescription());
        sender.sendMessage(ChatColor.YELLOW + "  API版本: " + ChatColor.WHITE + plugin.getDescription().getAPIVersion());
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GREEN + "  当前状态: 运行中");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GOLD + "" + ChatColor.STRIKETHROUGH + "======================================");
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("win9xplugin.reload")) {
            sender.sendMessage(ChatColor.RED + "你没有权限使用此命令！");
            return;
        }

        sender.sendMessage(ChatColor.YELLOW + "正在重载 Win9xPlugin...");

        plugin.reloadConfig();
        DebugLogger.reload();

        sender.sendMessage(ChatColor.GREEN + "Win9xPlugin 重载成功！");
        if (DebugLogger.isDebugEnabled()) {
            sender.sendMessage(ChatColor.GRAY + "调试模式: 已启用");
        }
        plugin.getLogger().info(sender.getName() + " 执行了插件重载");
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "只有玩家才能使用此命令！");
            return;
        }

        if (!sender.hasPermission("win9xplugin.give")) {
            sender.sendMessage(ChatColor.RED + "你没有权限使用此命令！");
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "用法: /win9xplugin give <物品ID>");
            return;
        }

        String itemId = args[1].toLowerCase();
        ItemStack item = getItemById(itemId);

        if (item == null) {
            sender.sendMessage(ChatColor.RED + "未知的物品ID: " + itemId);
            sender.sendMessage(ChatColor.GRAY + "使用 /win9xplugin help 查看可用物品ID");
            return;
        }

        player.getInventory().addItem(item);
        player.sendMessage(ChatColor.GREEN + "已获得物品: " + item.getItemMeta().getDisplayName());
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }

    private void handleGuide(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "只有玩家才能使用此命令！");
            return;
        }

        if (!sender.hasPermission("win9xplugin.guide")) {
            sender.sendMessage(ChatColor.RED + "你没有权限使用此命令！");
            return;
        }

        ItemStack guide = GuideBook.createGuideBook();
        player.getInventory().addItem(guide);
        player.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "你获得了 Win9xPlugin 指南！");
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }

    private void handleUnlock(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "只有玩家才能使用此命令！");
            return;
        }

        if (!sender.hasPermission("win9xplugin.unlock")) {
            sender.sendMessage(ChatColor.RED + "你没有权限使用此命令！");
            return;
        }

        UnlockGUI.openUnlockGUI(player);
    }

    private ItemStack getItemById(String id) {
        return switch (id) {
            case "phoenix_staff" -> PhoenixStaff.createStaff();
            case "phoenix_bow" -> PhoenixBow.createBow();
            case "phoenix_sword" -> PhoenixSword.createSword();
            case "phoenix_helmet" -> PhoenixArmor.createHelmet();
            case "phoenix_chestplate" -> PhoenixArmor.createChestplate();
            case "phoenix_leggings" -> PhoenixArmor.createLeggings();
            case "phoenix_boots" -> PhoenixArmor.createBoots();
            case "phoenix_essence" -> PhoenixMaterials.createEssence();
            case "fire_crystal" -> PhoenixMaterials.createFireCrystal();
            case "phoenix_feather" -> PhoenixMaterials.createPhoenixFeather();
            case "inferno_ingot" -> PhoenixMaterials.createInfernoIngot();
            case "wp_workbench" -> WPWorkbench.createWorkbench();
            case "wp_furnace" -> WPFurnace.createFurnace();
            case "elemental_staff" -> ElementalStaff.createStaff();
            case "elemental_bow" -> ElementalBow.createBow();
            case "elemental_sword" -> ElementalSword.createSword();
            case "elemental_helmet" -> ElementalArmor.createHelmet();
            case "elemental_chestplate" -> ElementalArmor.createChestplate();
            case "elemental_leggings" -> ElementalArmor.createLeggings();
            case "elemental_boots" -> ElementalArmor.createBoots();
            case "elemental_essence" -> ElementalMaterials.createElementalEssence();
            case "guide_book" -> GuideBook.createGuideBook();
            case "small_backpack" -> Backpack.createSmallBackpack();
            case "medium_backpack" -> Backpack.createMediumBackpack();
            case "large_backpack" -> Backpack.createLargeBackpack();
            case "trash_can" -> TrashCan.createTrashCan();
            case "chain_pickaxe" -> ChainPickaxe.createPickaxe();
            case "repair_machine" -> WPRepairMachine.createRepairMachine();
            case "repair_agent" -> RepairAgent.createRepairAgent();
            case "poor_glue" -> PoorGlue.createGlue();
            case "cheap_glue" -> CheapGlue.createGlue();
            case "brand_glue" -> BrandGlue.createGlue();
            default -> null;
        };
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            String input = args[0].toLowerCase();
            List<String> subCommands = List.of("help", "info", "reload", "give", "guide", "unlock", "research");
            for (String sub : subCommands) {
                if (sub.startsWith(input)) {
                    completions.add(sub);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            String input = args[1].toLowerCase();
            List<String> itemIds = List.of(
                    "phoenix_staff",
                    "phoenix_bow",
                    "phoenix_sword",
                    "phoenix_helmet",
                    "phoenix_chestplate",
                    "phoenix_leggings",
                    "phoenix_boots",
                    "phoenix_essence",
                    "fire_crystal",
                    "phoenix_feather",
                    "inferno_ingot",
                    "wp_workbench",
                    "wp_furnace",
                    "elemental_staff",
                    "elemental_bow",
                    "elemental_sword",
                    "elemental_helmet",
                    "elemental_chestplate",
                    "elemental_leggings",
                    "elemental_boots",
                    "elemental_essence",
                    "guide_book",
                    "small_backpack",
                    "medium_backpack",
                    "large_backpack",
                    "trash_can",
                    "chain_pickaxe",
                    "repair_machine",
                    "repair_agent",
                    "poor_glue",
                    "cheap_glue",
                    "brand_glue"
            );
            for (String id : itemIds) {
                if (id.startsWith(input)) {
                    completions.add(id);
                }
            }
        }

        return completions;
    }
}
