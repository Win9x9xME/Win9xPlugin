package com.win9xplugin.commands;

import com.win9xplugin.weapons.PhoenixArmor;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GiveArmorCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "只有玩家才能使用此命令！");
            return true;
        }

        if (!player.hasPermission("win9xplugin.givearmor")) {
            player.sendMessage(ChatColor.RED + "你没有权限使用此命令！");
            return true;
        }

        ItemStack helmet = PhoenixArmor.createHelmet();
        ItemStack chestplate = PhoenixArmor.createChestplate();
        ItemStack leggings = PhoenixArmor.createLeggings();
        ItemStack boots = PhoenixArmor.createBoots();

        player.getInventory().setHelmet(helmet);
        player.getInventory().setChestplate(chestplate);
        player.getInventory().setLeggings(leggings);
        player.getInventory().setBoots(boots);

        player.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "你获得了凤凰铠甲套装！");
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);

        return true;
    }
}
