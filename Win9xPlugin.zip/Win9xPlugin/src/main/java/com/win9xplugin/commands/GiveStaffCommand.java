package com.win9xplugin.commands;

import com.win9xplugin.weapons.PhoenixStaff;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GiveStaffCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "只有玩家才能使用此命令！");
            return true;
        }

        if (!player.hasPermission("win9xplugin.givestaff")) {
            player.sendMessage(ChatColor.RED + "你没有权限使用此命令！");
            return true;
        }

        ItemStack staff = PhoenixStaff.createStaff();
        player.getInventory().addItem(staff);
        player.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "你获得了 凤凰法杖！");
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);

        return true;
    }
}
