package com.win9xplugin.unlock;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UnlockData {

    private static JavaPlugin plugin;
    private static File dataFile;
    private static FileConfiguration data;

    public static void init(JavaPlugin pl) {
        plugin = pl;
        dataFile = new File(plugin.getDataFolder(), "unlock_data.yml");
        reloadData();
    }

    public static void reloadData() {
        if (!dataFile.exists()) {
            try {
                dataFile.getParentFile().mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("无法创建解锁数据文件: " + e.getMessage());
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    public static void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("无法保存解锁数据: " + e.getMessage());
        }
    }

    private static String getPlayerPath(UUID uuid) {
        return "players." + uuid.toString() + ".unlocked";
    }

    public static boolean isUnlocked(Player player, String itemId) {
        List<String> unlocked = data.getStringList(getPlayerPath(player.getUniqueId()));
        return unlocked.contains(itemId);
    }

    public static void unlockItem(Player player, String itemId) {
        UUID uuid = player.getUniqueId();
        String path = getPlayerPath(uuid);
        List<String> unlocked = data.getStringList(path);

        if (!unlocked.contains(itemId)) {
            unlocked.add(itemId);
            data.set(path, unlocked);
            saveData();
        }
    }

    public static List<String> getUnlockedItems(Player player) {
        return new ArrayList<>(data.getStringList(getPlayerPath(player.getUniqueId())));
    }

    public static void resetPlayerData(Player player) {
        UUID uuid = player.getUniqueId();
        data.set("players." + uuid.toString(), null);
        saveData();
    }

    public static int getPlayerUnlockCount(Player player) {
        return getUnlockedItems(player).size();
    }

    public static int getTotalUnlockableCount() {
        return UnlockItem.UNLOCK_COSTS.size();
    }
}
