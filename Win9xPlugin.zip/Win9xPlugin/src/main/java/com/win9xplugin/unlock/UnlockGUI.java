package com.win9xplugin.unlock;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class UnlockGUI implements Listener {

    private static final String GUI_TITLE = ChatColor.GOLD + "" + ChatColor.BOLD + "物品研究";
    private static final int GUI_SIZE = 54;
    private static final int[] ITEM_SLOTS = {10, 12, 14, 16, 28, 30, 32, 34, 37, 39, 41, 43};

    private static final Map<UUID, Inventory> openUnlockGUIs = new HashMap<>();
    private static final Map<UUID, Integer> playerPage = new HashMap<>();
    private static JavaPlugin plugin;
    private static UnlockGUI instance;

    public UnlockGUI() {
        instance = this;
    }

    public static void setPlugin(JavaPlugin pl) {
        plugin = pl;
    }

    public static void openUnlockGUI(Player player) {
        playerPage.put(player.getUniqueId(), 0);
        instance.openUnlockGUIWithPage(player, 0);
    }

    private void openUnlockGUIWithPage(Player player, int page) {
        playerPage.put(player.getUniqueId(), page);

        Inventory inv = Bukkit.createInventory(null, GUI_SIZE, GUI_TITLE);

        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        if (glassMeta != null) {
            glassMeta.setDisplayName(" ");
            glass.setItemMeta(glassMeta);
        }

        for (int i = 0; i < GUI_SIZE; i++) {
            inv.setItem(i, glass.clone());
        }

        setupTopRow(inv, player);
        setupItemList(inv, player, page);
        setupBottomRow(inv, player, page);

        openUnlockGUIs.put(player.getUniqueId(), inv);
        player.openInventory(inv);
    }

    private void setupTopRow(Inventory inv, Player player) {
        int expLevel = player.getLevel();
        int totalExp = getTotalExperience(player);
        int unlocked = UnlockData.getPlayerUnlockCount(player);
        int total = UnlockItem.UNLOCK_COSTS.size();

        ItemStack infoItem = new ItemStack(Material.EXPERIENCE_BOTTLE);
        ItemMeta infoMeta = infoItem.getItemMeta();
        if (infoMeta != null) {
            infoMeta.setDisplayName(ChatColor.YELLOW + "" + ChatColor.BOLD + "当前经验等级: " + expLevel);
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "累计经验值: " + totalExp);
            lore.add("");
            lore.add(ChatColor.GREEN + "已解锁: " + unlocked + "/" + total);
            infoMeta.setLore(lore);
            infoItem.setItemMeta(infoMeta);
        }
        inv.setItem(4, infoItem);

        ItemStack statusItem = new ItemStack(Material.BOOK);
        ItemMeta statusMeta = statusItem.getItemMeta();
        if (statusMeta != null) {
            statusMeta.setDisplayName(ChatColor.AQUA + "" + ChatColor.BOLD + "解锁状态");
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GREEN + "已解锁的物品可以直接使用");
            lore.add(ChatColor.RED + "未解锁的物品需要研究后使用");
            lore.add("");
            lore.add(ChatColor.GRAY + "研究消耗经验等级");
            statusMeta.setLore(lore);
            statusItem.setItemMeta(statusMeta);
        }
        inv.setItem(8, statusItem);
    }

    private static void setupItemList(Inventory inv, Player player, int page) {
        List<String> allItems = new ArrayList<>(UnlockItem.UNLOCK_COSTS.keySet());
        int itemsPerPage = 12;
        int startIndex = page * itemsPerPage;
        int endIndex = Math.min(startIndex + itemsPerPage, allItems.size());

        int slotIndex = 0;
        for (int i = startIndex; i < endIndex && slotIndex < ITEM_SLOTS.length; i++) {
            String itemId = allItems.get(i);
            boolean unlocked = UnlockData.isUnlocked(player, itemId);
            int cost = UnlockItem.getCost(itemId);
            ItemStack item = createUnlockItem(itemId, cost, unlocked);
            inv.setItem(ITEM_SLOTS[slotIndex], item);
            slotIndex++;
        }
    }

    private static void setupBottomRow(Inventory inv, Player player, int page) {
        List<String> allItems = new ArrayList<>(UnlockItem.UNLOCK_COSTS.keySet());
        int totalPages = (int) Math.ceil((double) allItems.size() / 12);

        ItemStack prevItem = new ItemStack(Material.ARROW);
        ItemMeta prevMeta = prevItem.getItemMeta();
        if (prevMeta != null) {
            prevMeta.setDisplayName(ChatColor.YELLOW + "上一页");
            prevItem.setItemMeta(prevMeta);
        }
        inv.setItem(45, prevItem);

        ItemStack pageItem = new ItemStack(Material.PAPER);
        ItemMeta pageMeta = pageItem.getItemMeta();
        if (pageMeta != null) {
            pageMeta.setDisplayName(ChatColor.WHITE + "第 " + (page + 1) + " / " + Math.max(1, totalPages) + " 页");
            pageItem.setItemMeta(pageMeta);
        }
        inv.setItem(49, pageItem);

        ItemStack nextItem = new ItemStack(Material.ARROW);
        ItemMeta nextMeta = nextItem.getItemMeta();
        if (nextMeta != null) {
            nextMeta.setDisplayName(ChatColor.YELLOW + "下一页");
            nextItem.setItemMeta(nextMeta);
        }
        inv.setItem(53, nextItem);
    }

    private static ItemStack createUnlockItem(String itemId, int cost, boolean unlocked) {
        Material material = getMaterialForItem(itemId);
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        if (meta == null) {
            return item;
        }

        if (unlocked) {
            meta.setDisplayName(ChatColor.GREEN + "" + ChatColor.BOLD + UnlockItem.getDisplayName(itemId));
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GREEN + "✓ 已解锁");
            lore.add("");
            lore.add(ChatColor.GRAY + "点击查看物品信息");
            meta.setLore(lore);
        } else {
            meta.setDisplayName(ChatColor.RED + "" + ChatColor.BOLD + UnlockItem.getDisplayName(itemId));
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.RED + "✗ 未解锁");
            lore.add("");
            lore.add(ChatColor.YELLOW + "研究费用: " + cost + " 经验等级");
            lore.add("");
            lore.add(ChatColor.GRAY + "左键花费经验解锁");
            meta.setLore(lore);
        }

        item.setItemMeta(meta);
        return item;
    }

    private static Material getMaterialForItem(String itemId) {
        if (itemId.contains("staff")) {
            return Material.BLAZE_ROD;
        } else if (itemId.contains("bow")) {
            return Material.BOW;
        } else if (itemId.contains("sword")) {
            return Material.DIAMOND_SWORD;
        } else if (itemId.contains("helmet")) {
            return Material.DIAMOND_HELMET;
        } else if (itemId.contains("chestplate")) {
            return Material.DIAMOND_CHESTPLATE;
        } else if (itemId.contains("leggings")) {
            return Material.DIAMOND_LEGGINGS;
        } else if (itemId.contains("boots")) {
            return Material.DIAMOND_BOOTS;
        } else if (itemId.contains("pickaxe")) {
            return Material.DIAMOND_PICKAXE;
        } else if (itemId.contains("workbench")) {
            return Material.CRAFTING_TABLE;
        } else if (itemId.contains("furnace")) {
            return Material.FURNACE;
        } else if (itemId.contains("repair")) {
            return Material.ANVIL;
        } else if (itemId.contains("glue")) {
            return Material.SLIME_BALL;
        } else if (itemId.contains("essence")) {
            return Material.NETHER_STAR;
        } else if (itemId.contains("crystal") || itemId.contains("feather") || itemId.contains("ingot")) {
            return Material.BLAZE_POWDER;
        } else {
            return Material.DIAMOND;
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        Inventory openInv = openUnlockGUIs.get(player.getUniqueId());
        if (openInv == null || !event.getInventory().equals(openInv)) {
            return;
        }

        event.setCancelled(true);
        int slot = event.getRawSlot();

        if (slot == 45) {
            int currentPage = playerPage.getOrDefault(player.getUniqueId(), 0);
            if (currentPage > 0) {
                openUnlockGUIWithPage(player, currentPage - 1);
            }
            return;
        }

        if (slot == 53) {
            List<String> allItems = new ArrayList<>(UnlockItem.UNLOCK_COSTS.keySet());
            int totalPages = (int) Math.ceil((double) allItems.size() / 12);
            int currentPage = playerPage.getOrDefault(player.getUniqueId(), 0);
            if (currentPage < totalPages - 1) {
                openUnlockGUIWithPage(player, currentPage + 1);
            }
            return;
        }

        for (int itemSlot : ITEM_SLOTS) {
            if (slot == itemSlot) {
                ItemStack clickedItem = event.getInventory().getItem(slot);
                if (clickedItem == null || !clickedItem.hasItemMeta()) {
                    return;
                }

                String displayName = ChatColor.stripColor(clickedItem.getItemMeta().getDisplayName());
                String itemId = getItemIdByDisplayName(displayName);

                if (itemId == null) {
                    return;
                }

                boolean unlocked = UnlockData.isUnlocked(player, itemId);

                if (unlocked) {
                    player.sendMessage(ChatColor.GREEN + "【" + displayName + "】已解锁，可以直接使用！");
                } else {
                    int cost = UnlockItem.getCost(itemId);
                    if (player.getLevel() >= cost) {
                        player.setLevel(player.getLevel() - cost);
                        UnlockData.unlockItem(player, itemId);
                        player.sendMessage(ChatColor.GREEN + "成功研究【" + displayName + "】！");
                        player.sendMessage(ChatColor.GRAY + "消耗 " + cost + " 经验等级");
                        openUnlockGUIWithPage(player, playerPage.getOrDefault(player.getUniqueId(), 0));
                    } else {
                        player.sendMessage(ChatColor.RED + "经验等级不足！需要 " + cost + " 经验等级");
                        player.sendMessage(ChatColor.GRAY + "当前: " + player.getLevel() + " 经验等级");
                    }
                }
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            openUnlockGUIs.remove(player.getUniqueId());
        }
    }

    private String getItemIdByDisplayName(String displayName) {
        for (Map.Entry<String, String> entry : UnlockItem.ITEM_DISPLAY_NAMES.entrySet()) {
            if (entry.getValue().equals(displayName)) {
                return entry.getKey();
            }
        }
        return null;
    }

    private int getTotalExperience(Player player) {
        int level = player.getLevel();
        int exp = 0;

        if (level <= 16) {
            exp = (int) (level * level + 6 * level);
        } else if (level <= 31) {
            exp = (int) (2.5 * level * level - 40.5 * level + 360);
        } else {
            exp = (int) (4.5 * level * level - 162.5 * level + 2220);
        }

        exp += (int) (player.getExp() * getExpToNextLevel(level));
        return exp;
    }

    private int getExpToNextLevel(int level) {
        if (level <= 15) {
            return 2 * level + 7;
        } else if (level <= 30) {
            return 5 * level - 38;
        } else {
            return 9 * level - 158;
        }
    }
}
