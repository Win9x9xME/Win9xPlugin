package com.win9xplugin.unlock;

import org.bukkit.ChatColor;

import java.util.HashMap;
import java.util.Map;

public class UnlockItem {

    public static final Map<String, Integer> UNLOCK_COSTS = new HashMap<>();
    public static final Map<String, String> ITEM_DISPLAY_NAMES = new HashMap<>();

    public static void init() {
        // 工具分类
        addItem("chain_pickaxe", 15, "连锁采集稿");

        // 材料分类
        addItem("phoenix_essence", 5, "凤凰精华");
        addItem("fire_crystal", 8, "烈焰水晶");
        addItem("phoenix_feather", 10, "凤凰羽毛");
        addItem("inferno_ingot", 12, "熔岩锭");
        addItem("elemental_essence", 8, "元素精华");
        addItem("water_essence", 5, "水元素精华");
        addItem("earth_essence", 5, "土元素精华");
        addItem("fire_essence", 5, "火元素精华");
        addItem("air_essence", 5, "气元素精华");
        addItem("elemental_core", 20, "元素核心");
        addItem("repair_agent", 25, "万能修补剂");
        addItem("poor_glue", 3, "劣质胶水");
        addItem("cheap_glue", 5, "廉价胶水");
        addItem("brand_glue", 10, "品牌胶水");

        // 武器分类
        addItem("phoenix_staff", 30, "凤凰法杖");
        addItem("phoenix_bow", 25, "凤凰之弓");
        addItem("phoenix_sword", 30, "凤凰之剑");
        addItem("elemental_staff", 30, "元素法杖");
        addItem("elemental_bow", 25, "元素之弓");
        addItem("elemental_sword", 30, "元素之剑");

        // 装备分类
        addItem("phoenix_helmet", 20, "凤凰战盔");
        addItem("phoenix_chestplate", 25, "凤凰铠甲");
        addItem("phoenix_leggings", 22, "凤凰护腿");
        addItem("phoenix_boots", 18, "凤凰战靴");
        addItem("elemental_helmet", 20, "元素头盔");
        addItem("elemental_chestplate", 25, "元素胸甲");
        addItem("elemental_leggings", 22, "元素护腿");
        addItem("elemental_boots", 18, "元素战靴");

        // 机器分类
        addItem("wp_workbench", 10, "WP铸造台");
        addItem("wp_furnace", 10, "WP熔铸炉");
        addItem("wp_repair_machine", 20, "WP修复机");
    }

    private static void addItem(String id, int cost, String displayName) {
        UNLOCK_COSTS.put(id, cost);
        ITEM_DISPLAY_NAMES.put(id, displayName);
    }

    public static int getCost(String itemId) {
        return UNLOCK_COSTS.getOrDefault(itemId, 0);
    }

    public static String getDisplayName(String itemId) {
        return ITEM_DISPLAY_NAMES.getOrDefault(itemId, itemId);
    }

    public static boolean isUnlockable(String itemId) {
        return UNLOCK_COSTS.containsKey(itemId);
    }

    public static String getRarity(int cost) {
        if (cost <= 5) {
            return ChatColor.GRAY + "普通";
        } else if (cost <= 10) {
            return ChatColor.GREEN + "优良";
        } else if (cost <= 15) {
            return ChatColor.AQUA + "稀有";
        } else if (cost <= 20) {
            return ChatColor.LIGHT_PURPLE + "史诗";
        } else {
            return ChatColor.GOLD + "传说";
        }
    }
}
